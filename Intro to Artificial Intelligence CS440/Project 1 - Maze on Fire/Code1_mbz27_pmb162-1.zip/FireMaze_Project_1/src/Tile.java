/**
 * Class that represents the generalization of a tile in the maze
 * @author Michael Zhang, Prasanth Balaji
 * On our honor, we have neither received nor given 
 * any unauthorized assistance on this assignment
 */
public abstract class Tile implements Comparable {
	private Tile parent;
	boolean isBlock, isStart, isEnd;
    public int distance;
	int x, y;
	
	/**
	 * Constructor for a general tile
	 * @param parent
	 * @param isBlock
	 * @param isStart
	 * @param isEnd
	 * @param x
	 * @param y
	 */
	public Tile( Tile parent, boolean isBlock, boolean isStart, boolean isEnd, int x, int y ) {
		this.parent = parent;
		this.isBlock = isBlock;
		this.isStart = isStart;
		this.isEnd = isEnd;
		this.x = x;
		this.y = y;
        distance = 0;
		
	}

	/**
	 * Coordinate Constructor that only stores the coordinate (x, y)
	 * @param x
	 * @param y
	 */
	public Tile ( int x, int y ) {
		this.x = x;
		this.y = y;
		this.parent = null;
		this.isBlock = false;
		this.isStart = false;
		this.isEnd = false;

	}
	
	/**
	 * General equals method to compare two tiles
	 */
	@Override
	public boolean equals(Object o) {
	    if( (o instanceof Tile) )
	        return (((Tile) o).x == this.x) && (((Tile) o).y == this.y);
	    
	    return false;
	}
	
	/**
	 * A simple method to convert any tile method into a coordinate string
	 */
	@Override
	public String toString() {
	    return this.x + " ," + this.y;
	}

	/**
	 * Getter method for the parent pointer
	 * @return
	 */
	public Tile getParent() {
	    return this.parent;
	}
	
	/**
	 * Setter method for the parent pointer
	 * @param parent
	 */
	public void setParent(Tile parent) {
	    this.parent = parent;
	}
	
	/**
	 * An abstract method that any type of tile needs to implement
	 * (Mostly used for aStar heuristic or any algorithm that needs a priority queue)
	 */
	@Override
	public abstract int compareTo(Object o);
	
	/**
	 * An abstract method that any type o tile needs to implement to define
	 * if a tile is valid or not
	 * @return
	 */
	public abstract boolean isValid();
	
}

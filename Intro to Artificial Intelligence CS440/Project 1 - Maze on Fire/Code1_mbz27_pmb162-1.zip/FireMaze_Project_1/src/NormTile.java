/**
 * Class that represents a tile that cannot be on fire
 * @author Michael Zhang, Prasanth Balaji
 * On our honor, we have neither received nor given 
 * any unauthorized assistance on this assignment
 */
public class NormTile extends Tile{
    
    /**
     * Constructor for a tile that cannot be on fire
     * @param parent
     * @param isBlock
     * @param isStart
     * @param isEnd
     * @param x
     * @param y
     */
    public NormTile(Tile parent, boolean isBlock, boolean isStart, boolean isEnd, int x, int y) {
        super(parent, isBlock, isStart, isEnd, x, y);

    }
    
    /**
     * Coordinate Constructor that only stores the coordinate (x, y)
     * @param x
     * @param y
     */
    public NormTile(int x, int y) {
        super(x, y);
    }
    
    /**
     * Method that the aStar method uses to sort the PriorityQueue
     * Using the (euclidean distance to goal) + (number of nodes from current location to the start) heuristic to
     * compare between two tiles
     */
    @Override
    public int compareTo(Object o) {
        if ( o instanceof Tile ) {
            // Calculates the (euclidean distance to goal) + (number of nodes from current location to the start) heuristic
            double dstToEndForObj = Math.sqrt( Math.pow( FireMaze.end.x - ( ( Tile )o ).x, 2 ) + Math.pow( FireMaze.end.y - ( (Tile ) o ).y, 2 ) );
            double dstToEndForThis = Math.sqrt( Math.pow( FireMaze.end.x - this.x, 2 ) + Math.pow( FireMaze.end.y - this.y, 2 ) );
            double heuristicThis = this.distance + dstToEndForThis;
            double heuristicObj = ( ( Tile ) o ).distance + dstToEndForObj;

            if ( heuristicThis - heuristicObj < 0 )
                return -1;
            else if ( heuristicThis - heuristicObj > 0 )
                return 1;
            else
                return 0;
        }
        return -1;

    }
    
    /**
     * A simple method to define whether the tile is valid or not 
     * (ie. not a block)
     */
    @Override
    public boolean isValid() {
        return (!super.isBlock);
    }
    

}

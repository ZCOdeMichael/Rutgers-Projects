

import java.util.*;

/**
 * The main class to run all of the algorithms
 * @author Michael Zhang, Prasanth Balaji
 * On our honor, we have neither received nor given 
 * any unauthorized assistance on this assignment
 */
public class FireMaze {
    static final int numIterations = 20;
    static final int fireStepLimit = 10;
    static Tile[][] maze;
    static double prob;
    static int dimension;
    static Tile start;
    static Tile end;
    static double q;
    
    
    static int num_of_invalid_tiles = 0;

    static int num_BFS = 0;
    static int num_A = 0;
    
    /**
     * Handle arguments please enter the arguments in this order and omit the prob. of fire spread
     * argument if the algo. does not need fire.
     * 
     * java FireMaze [type of algo to run] [block density] [maze dimension] [prob. of fire spread]
     * type of algo to run: dfs, bfs, astar, strat1, strat2, strat3
     * 
     * @param args
     */
    public static void main(String[] args) {
        if(args.length >= 3 && args.length <= 4) {
            System.out.println("No enough inputs");
        }
        
        String algo = args[0];
    	
    	if(algo.equals("dfs") || algo.equals("bfs") || algo.equals("astar")) {
    	    prob = Double.parseDouble(args[1]);
            dimension = Integer.parseInt(args[2]);
    	    
    	    
    	    maze = new NormTile[ dimension ][ dimension ]; 
            start = new NormTile( 0, 0 );
            end = new NormTile( dimension-1, dimension-1 );
            makeMaze( start, end );
            
            boolean temp;
            if(algo.equals("dfs")) {
                temp = dfsAlgo(start, end);
            }else if(algo.equals("bfs")) {
                temp = bfsAlgo(start, end);
            }else {
                temp = aStar(start, end); 
            }
            
            System.out.println("Algo status: " + temp + "\n");
            int count = 0;
            if(temp) {
                
                for ( int i = 0; i < dimension; i++ ){
                    for ( int j = 0; j < dimension; j++ ){
                        if(isPath(start, end, i, j)) {
                            System.out.print(" X");
                            count++;
                        }else if ( maze[ i ][ j ].isBlock == true )
                            System.out.print( " 1" );
                        else
                            System.out.print( " 0" );   
                    }
                    System.out.println();   
                }
                System.out.println();
            }
            System.out.println("Path length: " + count); 
            
    	}else if(algo.equals("strat1") || algo.equals("strat2")) {
    	    prob = Double.parseDouble(args[1]);
            dimension = Integer.parseInt(args[2]);
            q = Double.parseDouble(args[3]);
    	    
    	    maze = new FireTile[ dimension ][ dimension ];
            start = new FireTile( 0, 0 );
            end = new FireTile( dimension-1, dimension-1 );
            setStartFire( ( FireTile) start, ( FireTile) end );
            
            boolean temp;
            if(algo.equals("strat1")) {
                temp = strat_1( ( FireTile) start, ( FireTile) end );
                 
            }else {
                temp = strat_2( ( FireTile) start, ( FireTile) end );
            }
            System.out.println("Algo status: " + temp);
            
    	}else if(algo.equals("strat3")) {
    	    prob = Double.parseDouble(args[1]);
            dimension = Integer.parseInt(args[2]);
            q = Double.parseDouble(args[3]);
    	    
    	    maze = new Strat3Tile[ dimension ][ dimension ];
            start = new Strat3Tile( 0, 0 );
            end = new Strat3Tile( dimension-1, dimension-1 );
            setStartFireStrat3( ( Strat3Tile) start, ( Strat3Tile) end );
            boolStack temp = strat_3(start, end);
            
            if(temp.result) {
                System.out.println("FINAL PATH");
                for(int i = 0; i < dimension; i++) {
                    for(int j = 0; j < dimension; j++) {
                        if(temp.path.contains(maze[i][j])) {
                            System.out.print(" X");
                        }else if(((FireTile)maze[i][j]).isFire) {
                            System.out.print(" *");
                        }else if(maze[i][j].isBlock) {
                            System.out.print(" 1");
                        }else {
                            System.out.print(" 0");
                        }
                    }
                    System.out.println();
                }
            }else {
                for(int i = 0; i < dimension; i++) {
                    for(int j = 0; j < dimension; j++) {
                        if(((FireTile)maze[i][j]).isFire) {
                            System.out.print(" *");
                        }else if(temp.path.contains(maze[i][j])) {
                            System.out.print(" X");
                        }else if(maze[i][j].isBlock) {
                            System.out.print(" 1");
                        }else {
                            System.out.print(" 0");
                        }
                    }
                    System.out.println();
                }
            }    
            System.out.println("Algo status: " + temp.result);
        }else {
            System.out.println("Invalid input");
        }
    	
    }
    
    
    /**
     * A simple method to check if index (x, y) in the maze is a path.
     * @param loc1
     * @param loc2
     * @param x
     * @param y
     * @return
     */
    private static boolean isPath( Tile loc1, Tile loc2, int x, int y ) {
        Tile ptr = maze[loc2.x][loc2.y];
        if(x == loc1.x && y == loc1.y) {
            return true;
        }
        // Loops through the path and checks if index (x, y) is on the path
        while(!(ptr.x == loc1.x && ptr.y == loc1.y)) {
            if(ptr.x == x && ptr.y == y) {
                return true;
            }
            ptr = ptr.getParent();
        }

        return false;
    }

    /**
     * The method that is used to make a make with no fire and
     * is only used for part 1 of the project [dfs, bfs, astar].
     * @param tile1
     * @param tile2
     */
    public static void makeMaze( Tile tile1, Tile tile2 ) {
    	for ( int i = 0; i < dimension; i++ ) {
    		for ( int j = 0; j < dimension; j++ ) {
    		    
    		    // Creates the start and end tiles
    			if ( i == tile1.x && j == tile1.y )
    				maze[ i ][ j ] = new NormTile( null, false, true, false, i, j );
    			if ( i == tile2.x && j == tile2.y )
    				maze[ i ][ j ] = new NormTile( null, false, false, true, i, j );
    			
    			// Tiles that are not the start and end tiles
    			Tile newTile;
    			if ( !( ( i == tile1.x && j == tile1.y ) || ( i == tile2.x && j == tile2.y  ) ) ) {
    			    if ( Math.random() <= prob ) {
        				// When the tile is a block
        				newTile = new NormTile( null, true, false, false, i, j );
        				maze[ i ][ j ] = newTile;
        			}
        			else {
        				// When the tile is not a block
        				newTile = new NormTile( null, false, false, false, i, j );
        				maze[ i ][ j ] = newTile;				
        			}	
    			}
    		}
    	}
    }
    
    /**
     * This method is a dfs algorithm that can traverse any type of maze.
     * (a maze on fire or a maze that is not on fire)
     * @param loc1
     * @param loc2
     * @return
     */
    public static boolean dfsAlgo( Tile loc1, Tile loc2 ) {
        // Initialize fringe with goal node
        Stack< Tile > fringe = new Stack<>();
        fringe.push( maze[ loc1.x ][ loc1.y ] );
        
        // Initialize closedSet to deal with loops
        Set< Tile > closedSet = new HashSet<>();
        
        while ( ! fringe.isEmpty() ) {
            Tile current = fringe.pop();
            
            // Checks if it has reached the goal node
            if ( current.x == loc2.x && current.y == loc2.y )
                return true;
            else {
                
                // Checks if tile has already been explored
                if ( ! closedSet.contains( current ) ) {
                    
                    // Generates valid tiles
                    if ( isValidTile(current.x + 1, current.y) != null ) {
                        fringe.push(maze[current.x + 1][current.y]);
                        if (maze[current.x + 1][current.y].getParent() == null)
                            maze[current.x + 1][current.y].setParent(current);
                    }
                    if (isValidTile(current.x - 1, current.y) != null) {
                        fringe.push(maze[current.x - 1][current.y]);
                        if (maze[current.x - 1][current.y].getParent() == null)
                            maze[current.x - 1][current.y].setParent(current);
                    }
                    if (isValidTile(current.x, current.y - 1) != null) {
                        fringe.push(maze[current.x][current.y - 1]);
                        if (maze[current.x][current.y - 1].getParent() == null)
                            maze[current.x][current.y - 1].setParent(current);
                    }
                    if (isValidTile(current.x, current.y + 1) != null) {
                        fringe.push(maze[current.x][current.y + 1]);
                        if (maze[current.x][current.y + 1].getParent() == null)
                            maze[current.x][current.y + 1].setParent(current);
                    }

                    closedSet.add(current);
                }
            }
        }

        return false;
    }
    
    /**
     * This method is a bfs algorithm that can traverse any type of maze.
     * (a maze on fire or a maze that is not on fire)
     * @param tile1
     * @param tile2
     * @return
     */
    public static boolean bfsAlgo( Tile tile1, Tile tile2 ) {
        // Initialize fringe with goal node
        Queue<Tile> fringe = new LinkedList<>();
        fringe.add(maze[ tile1.x ][ tile1.y ]);
        
        // Initialize closedSet to deal with loops
        Set<Tile> closed_set = new HashSet<>();
        while(!fringe.isEmpty()) {
            Tile curr = fringe.remove();
            
            num_BFS++; // - TEMP NEED TO DELETE LATER AFTER TESTING
            
            // Checks if it has reached the goal node
            if(curr.x == tile2.x && curr.y == tile2.y) {
                return true;
            }else {
                
                // Checks if tile has already been explored
                if(!closed_set.contains(curr)) {
                    
                    // Generates valid tiles
                    if(isValidTile(curr.x+1, curr.y) != null) { 
                        fringe.add(maze[curr.x+1][curr.y]);
                        if(maze[curr.x+1][curr.y].getParent() == null)
                            maze[curr.x+1][curr.y].setParent(curr);
                    }

                    if(isValidTile(curr.x-1, curr.y) != null) {
                        fringe.add(maze[curr.x-1][curr.y]);
                        if(maze[curr.x-1][curr.y].getParent() == null)
                            maze[curr.x-1][curr.y].setParent(curr);
                    }
                    
                    if(isValidTile(curr.x, curr.y+1) != null) {
                        fringe.add(maze[curr.x][curr.y+1]);
                        if(maze[curr.x][curr.y+1].getParent() == null)
                            maze[curr.x][curr.y+1].setParent(curr);
                    }
                    if(isValidTile(curr.x, curr.y-1) != null) {
                        fringe.add(maze[curr.x][curr.y-1]);
                        if(maze[curr.x][curr.y-1].getParent() == null)
                            maze[curr.x][curr.y-1].setParent(curr);
                    }
                    
                    closed_set.add(curr);   
                }
            }
        }
    	return false;
    }
    
    /**
     * This method is a bfs algorithm that can traverse any type of maze.
     * (a maze on fire or a maze that is not on fire)
     * @param tile1
     * @param tile2
     * @return
     */
    public static boolean aStar( Tile tile1, Tile tile2 ) {
        
        // Initializes a PriorityQueue that will order the queue based of the compareTo method
        PriorityQueue<Tile> fringe = new PriorityQueue<>();
        fringe.add(maze[ tile1.x ][ tile1.y ]);

        // Initialize closedSet to deal with loops
        Set<Tile> closed_set = new HashSet<>();
        while(!fringe.isEmpty()) {
            Tile curr = fringe.remove();
            
            num_A++;  // - TEMP NEED TO DELETE LATER AFTER TESTING
            
            // Checks if it has reached the goal node
            if(curr.x == tile2.x && curr.y == tile2.y) {
                return true;
            }else {
                
                // Checks if tile has already been explored
                if(!closed_set.contains(curr)) {

                    // Generates valid tiles
                    if(isValidTile(curr.x+1, curr.y) != null) {
                        addFringAStar(fringe, maze[curr.x+1][curr.y], curr);
                    }

                    if(isValidTile(curr.x-1, curr.y) != null) {
                        addFringAStar(fringe, maze[curr.x-1][curr.y], curr);
                        
                    }

                    if(isValidTile(curr.x, curr.y+1) != null) {
                        addFringAStar(fringe, maze[curr.x][curr.y+1], curr);
                        
                    }
                    if(isValidTile(curr.x, curr.y-1) != null) {
                        addFringAStar(fringe, maze[curr.x][curr.y-1], curr);
                        
                    }

                    closed_set.add(curr);

                }
            }
        }
        
        
        return false;
    }
    
    /**
     * Specially made astar algorithm for strategy 3 that uses the utility heuristic in combination
     * with the (euclidean distance to goal) + (number of nodes from start) heuristic.
     * @param tile1
     * @param tile2
     * @return
     */
    public static boolean aStarStrat3( Tile tile1, Tile tile2 ) {
        
        // Resets all utility values to zero
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                ((Strat3Tile)maze[i][j]).utilityValue = 0;
            }
        }
        
        // Runs the fire simulations for numIterations times
        for(int k = 0; k < numIterations; k++) {
            int stepLimit = 0;
            Strat3Tile[][] ptrMaze = advance_fire_one_step3(maze);
            
            /**
             *  Runs the current fire simulation for a limited number of step to deal with cases
             *  when the fire does not spread; the fire is trapped; the fire is not present
             *  
             *  It also prevents the path from being skewed to the opposite edge of the map where the fire
             *  is not present (assuming the fireStepLimit variable isn't set too high)
             */
            while(stepLimit <= fireStepLimit){ //To deal with a trapped fire
                for(int i = 0; i < dimension; i++) {
                    for(int j = 0; j < dimension; j++) {
                        
                        // Tallies up the utility values for tiles that are not on fire and are not blocks
                        if(!((FireTile)ptrMaze[i][j]).isFire && !((FireTile)ptrMaze[i][j]).isBlock) {
                            ((Strat3Tile)maze[i][j]).utilityValue++;
                        }
                    }
                }
                ptrMaze = advance_fire_one_step3(ptrMaze);
                stepLimit++;
            }
        }
        
        // Averages all of the utility values in numIterations simulations
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                ((Strat3Tile)maze[i][j]).utilityValue /= numIterations;
            }
        }
        
        // Run regular aStar using the Strat3 compareTo method that combines the utility heuristic and euclidean distance heuristic
        return aStar(tile1, tile2);
    }
    
    /**
     * Method specifically for aStar that adds valid tiles to the fringe
     * @param fringe
     * @param tile
     * @param curr
     */
    public static void addFringAStar(PriorityQueue<Tile> fringe, Tile tile, Tile curr) {
        if(tile.getParent() == null) {
            tile.setParent(curr);
        }
        tile.distance = tile.getParent().distance + 1;
        fringe.add(tile);
    }
    
    /**
     * Method to advance the fire one step which is exclusively used for strat1 and strat2
     * @param mazeCurr
     * @return
     */
    public static Tile[][] advance_fire_one_step( Tile mazeCurr[][]) {
        
        // Makes a copy of the maze
        Tile copy[][] = new Tile[dimension][dimension];
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                FireTile temp = (FireTile)maze[i][j];
                copy[i][j] = new FireTile(temp.getParent(), temp.isBlock, temp.isStart, temp.isEnd, temp.x, temp.y, temp.isFire);
            }
        }
        
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                Tile curr = copy[i][j];
                
                if ( ! ( ( FireTile ) mazeCurr[i][j] ).isFire && (!mazeCurr[i][j].isBlock) ) {
                    
                    // Counts up neighboring fire tiles
                    int k = 0;
                    if(isValidIndex(i, j+1)) {
                        if( ( ( FireTile ) mazeCurr[i][j+1] ).isFire) {
                            k++;
                        }
                    }
                    if(isValidIndex(i, j-1)) {
                        if( ( ( FireTile ) mazeCurr[i][j-1] ).isFire) {
                            k++;
                        }
                    }
                    if(isValidIndex(i+1, j)) {
                        if( ( ( FireTile ) mazeCurr[i+1][j] ).isFire) {
                            k++;
                        }
                    }                    
                    if(isValidIndex(i-1, j)) {
                        if( ( ( FireTile ) mazeCurr[i-1][j] ).isFire) {
                            k++;
                        }
                    }
                    
                    double prob = 1 - Math.pow((1-q), k);
                    if(Math.random() <= prob) {
                        ( ( FireTile ) curr ).isFire = true;
                    }
                }
            }
        }
        return copy;
    }

    /**
     * Method to advance the fire one step which is exclusively used for strat1 and strat3
     * @param mazeCurr
     * @return
     */
    public static Strat3Tile[][] advance_fire_one_step3( Tile mazeCurr[][]) {
        
        // Makes a copy of the maze
        Strat3Tile copy[][] = new Strat3Tile[dimension][dimension];
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                Strat3Tile ptr = (Strat3Tile) mazeCurr[i][j];
                copy[i][j] = new Strat3Tile(ptr.getParent(), ptr.isBlock, ptr.isStart, ptr.isEnd, ptr.x, ptr.y, ptr.isFire);
            }
        }
        
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                Tile curr = copy[i][j];
                if ( ! ( ( Strat3Tile ) mazeCurr[i][j] ).isFire && (!mazeCurr[i][j].isBlock) ) {
                    
                    // Counts up neighboring fire tiles
                    int k = 0;
                    if(isValidIndex(i, j+1)) {
                        if( ( ( Strat3Tile ) mazeCurr[i][j+1] ).isFire) {
                            k++;
                        }
                    }
                    if(isValidIndex(i, j-1)) {
                        if( ( ( Strat3Tile ) mazeCurr[i][j-1] ).isFire) {
                            k++;
                        }
                    }
                    if(isValidIndex(i+1, j)) {
                        if( ( ( Strat3Tile ) mazeCurr[i+1][j] ).isFire) {
                            k++;
                        }
                    }                    
                    if(isValidIndex(i-1, j)) {
                        if( ( ( Strat3Tile ) mazeCurr[i-1][j] ).isFire) {
                            k++;
                        }
                    }
                    
                    double prob = 1 - Math.pow((1-q), k);
                    if(Math.random() <= prob) {
                        ( ( Strat3Tile ) curr ).isFire = true;
                    }
                }
            }
        }
        return copy;
    }
    
    /**
     * Method to make the maze and places a fire in a random tile.
     * This is used exclusively for the strat1, and strat2 since both of the methods use the FireTile class
     * @param tile1
     * @param tile2
     */
    public static void setStartFire( FireTile tile1, FireTile tile2 ) {
        int randomX = (int) (Math.random() * dimension);
        int randomY = (int) (Math.random() * dimension);

        // Sets a fire on a random tile
        maze[randomX][randomY] = new FireTile(null, false, false, false, randomX, randomY, true);
        
        for ( int i = 0; i < dimension; i++ ){
            for ( int j = 0; j < dimension; j++ ){
                
                // If the tile is the start or end and checks if the node is null or not
                if(((i == tile1.x && j == tile1.y) || (i == tile2.x && j == tile2.y)) && maze[i][j] != null) {
                    // Sets the start and end nodes - most likely the start or end node is on fire
                    if ( i == tile1.x && j == tile1.y )
                        maze[ i ][ j ].isStart = true;
                    else
                        maze[ i ][ j ].isEnd = true;
                }else if(((i == tile1.x && j == tile1.y) || (i == tile2.x && j == tile2.y)) && maze[i][j] == null) {
                    // Sets the start and end nodes
                    if ( i == tile1.x && j == tile1.y )
                        maze[ i ][ j ] = new FireTile( null, false, true, false, i, j, false );
                    else
                        maze[ i ][ j ] = new FireTile( null, false, false, true, i, j, false );
                }else {
                    // Creates the blocks in the maze and regular tiles
                    Tile newTile;
                    if(maze[i][j] == null) {
                        if (Math.random() <= prob){
                            // isBlock
                            newTile = new FireTile(null, true, false, false, i, j, false);
                            maze[i][j] = newTile;
                        }
                        else{
                            // not a block
                            newTile = new FireTile(null, false, false, false, i, j, false);
                            maze[i][j] = newTile;
                        }
                    }
                }
            }
        }
    }    
    
    /**
     * Strategy 1 is where the player selects an initial path and sticks to path even if fire
     * spreads to the path in the future.
     * @param loc1
     * @param loc2
     * @return
     */
    public static boolean strat_1( FireTile loc1, FireTile loc2) {
        
        // Print maze
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                if(maze[i][j].isBlock) {
                    System.out.print(" 1");
                } else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire ) {
                    System.out.print( " *" );
                }else {
                    System.out.print(" 0");
                }
            }
            System.out.println();
        }
        System.out.println();
        
        // Check if either the start or goal is on fire
        if(((FireTile)maze[loc1.x][loc1.y]).isFire || ((FireTile)maze[loc2.x][loc2.y]).isFire) {
            return false;
        }
        
        // Builds the initial aStar path
        boolean result = aStar(loc1, loc2);
        
        // Prints out the path
        if ( result ) {
            for(int i = 0; i < dimension; i++) {
                for(int j = 0; j < dimension; j++) {
                    if(maze[i][j].isBlock) {
                        System.out.print(" 1");
                    } else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire ) {
                        System.out.print( " *" );
                    }
                    else if(isPath(loc1, loc2, i, j)) {
                        System.out.print(" X");
                    }else {
                        System.out.print(" 0");
                    }
                }
                System.out.println();
            }
            System.out.println("Initial Path - A*");
        
            Tile ptr = maze[ loc2.x ][ loc2.y ];
            
            // Initializes a stack to store the path
            Stack<Tile> path = new Stack<>();
            path.push( maze[ loc2.x ][ loc2.y ] );
            while(!(ptr.x == start.x && ptr.y == start.y)) {
                path.push( ptr.getParent() );
                ptr = ptr.getParent();
            }
            
            // Pops the starting node
            path.pop();
            int count = 1;
            while( ! path.isEmpty() ) {
                
                // Player takes one step
                ptr = path.pop();
                maze = advance_fire_one_step( maze );
                
                // Print out current path and the current location of the player
                System.out.println( "\n\n" );
                for(int i = 0; i < dimension; i++) {
                    for(int j = 0; j < dimension; j++) {
                        if(maze[i][j].isBlock) {
                            System.out.print(" 1");
                        } else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire ) {
                            System.out.print( " *" );
                        } else if(maze[i][j].equals(ptr)) {
                            System.out.print( " #");
                        } else if(isPath(loc1, loc2, i, j)) {
                            System.out.print(" X");
                        }else {
                            System.out.print(" 0");
                        }
                    }
                    System.out.println();
                }
                System.out.println("Step #" + count);
                
                // Checks if the player is on fire
                if ( ( ( FireTile ) maze[ptr.x][ptr.y] ).isFire )
                    return false;
                count++;
            }   
            
            // Player survives the maze
            return true;
        }
        
        // If there is no valid path to the goal
        return result;
    }

    /**
     * Strategy 2 is where the player will recalculate the path to take every time it takes a step 
     * This strategy only considers the current maze and current tiles that are on fire
     * @param loc1
     * @param loc2
     * @return
     */
    public static boolean strat_2( FireTile loc1, FireTile loc2 ) {
        // Check if either the start or goal is on fire
        if(((FireTile)maze[loc1.x][loc1.y]).isFire || ((FireTile)maze[loc2.x][loc2.y]).isFire) {
            return false;
        }
        
        // Stores the path the player takes
        Stack< Tile > entirePath = new Stack<>();
        
        // First path the player takes
        Stack< Tile > firstPath = new Stack<>();
        boolean result = aStar( loc1, loc2 );
        
        if ( result ) {

            // Prints out starting path
            System.out.println( "PATH\n\n\n" );

            for ( int i = 0; i < dimension; i++ ) {
                for ( int j = 0; j < dimension; j++ ) {
                    if ( maze[ i ][ j ].isBlock )
                        System.out.print( " 1" );
                    else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire )
                        System.out.print( " *" );
                    else if ( isPath( loc1, loc2, i, j ) )
                        System.out.print( " X" );
                    else
                        System.out.print( " 0" );
                }
                System.out.println();
            }

            System.out.println( "\n\n\n" );

            // Getting the first step the player needs to take
            Tile ptr = maze[ loc2.x ][ loc2.y ];
            firstPath.push( ptr );
            while ( ! ( ptr.x == loc1.x && ptr.y == loc1.y ) ) {
                ptr = ptr.getParent();
                firstPath.push( ptr );
            }
            firstPath.pop(); 
            Tile step = firstPath.pop(); // Gets the first step
            
            int numSteps = 1;
            print( step, numSteps );
            numSteps++;
            entirePath.push( step );
            maze = advance_fire_one_step( maze );

            // Checks if the player is on fire
            if ( ( ( FireTile ) maze[step.x][step.y] ).isFire )
                return false;

            while ( ! ( step.x == loc2.x && step.y == loc2.y ) ) {
                resetPtrs();
                boolean resultLoop = aStar( step, loc2 );
                if ( ! resultLoop )
                    return false;
                
                // Recalculating a path
                Stack< Tile > newPath = newPath( step, loc2 );
                newPath.pop();
                step = newPath.pop();  // Gets the new path's first step
                
                entirePath.push( step );
                maze = advance_fire_one_step( maze );
                
                // Checks if the player is on fire
                if ( ( ( FireTile ) maze[step.x][step.y] ).isFire )
                    return false;
                print( step, numSteps );
                numSteps++;
            }
        }else {
            // Prints out path
            for ( int i = 0; i < dimension; i++ ) {
                for ( int j = 0; j < dimension; j++ ) {
                    if ( maze[ i ][ j ].isBlock )
                        System.out.print( " 1" );
                    else if ( entirePath.contains( new FireTile( i, j ) ) )
                        System.out.print( " X" );
                    else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire )
                        System.out.print( " *" );
                    else
                        System.out.print( " 0" );
               
                }
                System.out.println();
            }
            return result;
        }
        // Prints out path
        for ( int i = 0; i < dimension; i++ ) {
            for ( int j = 0; j < dimension; j++ ) {
                if(maze[i][j].equals(loc1)) {
                    System.out.print(" X");
                }else {
                    if ( maze[ i ][ j ].isBlock )
                        System.out.print( " 1" );
                    else if ( entirePath.contains( new FireTile( i, j ) ) )
                        System.out.print( " X" );
                    else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire )
                        System.out.print( " *" );
                    else
                        System.out.print( " 0" );
                }
            }
            System.out.println();
        }
        return result;
    }

    /**
     * Strategy 3 is where the player will recalculate the path to take every time it takes a step 
     * Unlike strategy 2, strategy 3 takes in account future iterations of the fire
     * @param loc1
     * @param loc2
     * @return
     */
    public static boolStack strat_3(Tile loc1, Tile loc2) {
        
            // Stack to store the final path the player takes
            Stack<Tile> path = new Stack<>();
            
            // Get the initial path
            boolean result = aStarStrat3(loc1, loc2);
            if(result) {
                
                // Gets the next step the player needs to take
                Stack<Tile> ptrStack = newPath(loc1, loc2);
                ptrStack.pop();
                Tile ptr = ptrStack.pop();
                
                path.push(ptr);
                maze = advance_fire_one_step3(maze);
                
                // On the first step player is on fire
                if(((Strat3Tile)maze[ptr.x][ptr.y]).isFire) {
                    return new boolStack(false, path);
                }
                
                while(!ptr.equals(loc2)) {
                    resetPtrs();
                    result = aStarStrat3(ptr, loc2);
                    
                    // Checks if there is still a path to the goal
                    if(result) { 
                        maze = advance_fire_one_step3(maze);
                        ptrStack = newPath(ptr, loc2);
                        ptrStack.pop();
                        ptr = ptrStack.pop();
                        path.push(ptr);
                        
                        // Check if the player steps into fire
                        if(((Strat3Tile)maze[ptr.x][ptr.y]).isFire) {
                            return new boolStack(false, path);
                        }
                    }else { 
                        // There is no path to the goal
                        return new boolStack(false, path);
                    }
                }
                // On first step player has reached the goal or successfully traversed the firemaze
                return new boolStack(true, path); 
            }
            // There isn't a path to the goal
            return new boolStack(false, path);
    }
        
    /**
     * Method to make the maze and places a fire in a random tile.
     * This is used exclusively for the strat3 since both of the methods use the Strat3Tile class
     * @param tile1
     * @param tile2
     */
    public static void setStartFireStrat3(Strat3Tile tile1, Strat3Tile tile2) {
        int randomX = (int) (Math.random() * dimension);
        int randomY = (int) (Math.random() * dimension);

        // Sets a fire on a random tile
        maze[randomX][randomY] = new Strat3Tile(null, false, false, false, randomX, randomY, true);
        num_of_invalid_tiles++;
        for ( int i = 0; i < dimension; i++ ){
            for ( int j = 0; j < dimension; j++ ){
                
                // If the tile is the start or end and checks if the node is null or not
                if(((i == tile1.x && j == tile1.y) || (i == tile2.x && j == tile2.y)) && maze[i][j] != null) {
                    // Sets the start and end nodes - most likely the start or end node is on fire
                    if ( i == tile1.x && j == tile1.y )
                        maze[ i ][ j ].isStart = true;
                    else
                        maze[ i ][ j ].isEnd = true;
                }else if(((i == tile1.x && j == tile1.y) || (i == tile2.x && j == tile2.y)) && maze[i][j] == null) {
                    // Sets the start and end nodes
                    if ( i == tile1.x && j == tile1.y )
                        maze[ i ][ j ] = new Strat3Tile( null, false, true, false, i, j, false );
                    else
                        maze[ i ][ j ] = new Strat3Tile( null, false, false, true, i, j, false );
                }else {
                    // Creates the blocks in the maze and regular tiles
                    Tile newTile;
                    if(maze[i][j] == null) {
                        if (Math.random() <= prob){
                            // isBlock
                            newTile = new Strat3Tile(null, true, false, false, i, j, false);
                            maze[i][j] = newTile;
                            num_of_invalid_tiles++;
                        }
                        else{
                            // not a block
                            newTile = new Strat3Tile(null, false, false, false, i, j, false);
                            maze[i][j] = newTile;
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Reset the parent pointers and distance value of every tile whenever we need to 
     * recalculate a path to the goal
     */
    public static void resetPtrs() {
        for ( int i = 0; i < dimension; i++ ){
            for ( int j = 0; j < dimension; j++ ){
                maze[ i ][ j ].setParent( null );
                maze[i][j].distance = 0;
            }
        }
    }

    /**
     * Gets the current path from loc to loc2 and prints out the path
     * @param loc
     * @param loc2
     * @return
     */
    public static Stack< Tile > newPath( Tile loc, Tile loc2 ) {
        Stack< Tile > newPath = new Stack<>();
        System.out.println( "NEW PATH\n" );
        for ( int i = 0; i < dimension; i++ ) {
            for (int j = 0; j < dimension; j++) {
                if(maze[i][j].equals(loc)) {
                    System.out.print(" #");
                }else {
                    if (maze[i][j].isBlock)
                        System.out.print(" 1");
                    else if ( isPath( loc, loc2, i, j ) )
                        System.out.print(" X");
                    else if (((FireTile) maze[i][j]).isFire)
                        System.out.print(" *");
                    else
                        System.out.print(" 0");
                }
            }
            System.out.println();
        }
        
        System.out.println( "\n" );
        
        // Storing the path into the stack
        Tile ptr = maze[ loc2.x ][ loc2.y ];
        newPath.push( ptr );
        while ( ! ( ptr.x == loc.x && ptr.y == loc.y ) ){
            ptr = ptr.getParent();
            newPath.push( ptr );
        }
        return newPath;
    }

    /**
     * Method to print out the current maze and path
     * @param step
     * @param numSteps
     */
    public static void print( Tile step, int numSteps ) {
        System.out.println( "STEP TAKEN: " + numSteps + "\n");
        for ( int i = 0; i < dimension; i++ ) {
            for ( int j = 0; j < dimension; j++ ) {
                if ( i == step.x && j == step.y )
                    System.out.print( " #");
                else {
                    if ( maze[ i ][ j ].isBlock )
                        System.out.print( " 1" );
                    else if ( ( ( FireTile ) maze[ i ][ j ] ).isFire )
                        System.out.print( " *" );
                    else if ( isPath( step, end, i, j ) )
                        System.out.print( " X" );
                    else
                        System.out.print( " 0" );
                }
            }
            System.out.println();
        }
        System.out.println( "\n\n\n\n" );
    }
    
    /**
     * Simple method to check if the index is out of bounds of the maze
     * @param x
     * @param y
     * @return
     */
    private static boolean isValidIndex(int x, int y) {
        return !(x < 0 || y < 0 || x >= dimension || y >= dimension);
    }
    
    /**
     * Simple method to check if the index is out of the bounds of the maze
     * and if the tile is valid (ie. not a block or fire)
     * @param x
     * @param y
     * @return
     */
    private static Tile isValidTile(int x, int y) {
        if(isValidIndex(x, y)) {
            if(maze[x][y].isValid()) {
                return maze[x][y];
            }
        }
        return null;
    }
    
    /**
     * A simple class to store the results and path of the strat 3
     * @author Michael Zhang, Prasanth Balaji
     *
     */
    private static class boolStack {
        public boolean result;
        public Stack<Tile> path;
        public boolStack(boolean result, Stack<Tile> path) {
            this.result = result;
            this.path = path;
        }
    }
    
}

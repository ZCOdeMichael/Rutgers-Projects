/**
 * Class that represents a tile that can be on fire
 * @author Michael Zhang, Prasanth Balaji
 * On our honor, we have neither received nor given 
 * any unauthorized assistance on this assignment
 */
public class FireTile extends Tile{
    
    public boolean isFire;
    
    /**
     * Constructor for a tile that can be on fire
     * @param parent
     * @param isBlock
     * @param isStart
     * @param isEnd
     * @param x
     * @param y
     * @param isFire
     */
    public FireTile(Tile parent, boolean isBlock, boolean isStart, boolean isEnd, int x, int y, boolean isFire) {
        super(parent, isBlock, isStart, isEnd, x, y);
        this.isFire = isFire;
    }
    
    /**
     * Coordinate Constructor that only stores the coordinate (x, y)
     * @param x
     * @param y
     */
    public FireTile(int x, int y) {
        super(x, y);
        this.isFire = false;
    }

    /**
     * Method that the aStar method uses to sort the PriorityQueue
     * Using the (euclidean distance to goal) + (number of nodes from current location to the start) heuristic to
     * compare between two tiles
     */
    @Override
    public int compareTo(Object o) { 
        if ( o instanceof Tile ) {
            // Calculates the (euclidean distance to goal) + (number of nodes from current location to the start) heuristic
            double dstToEndForObj = Math.sqrt( Math.pow( FireMaze.end.x - ( ( Tile )o ).x, 2 ) + Math.pow( FireMaze.end.y - ( (Tile ) o ).y, 2 ) );
            double dstToEndForThis = Math.sqrt( Math.pow( FireMaze.end.x - this.x, 2 ) + Math.pow( FireMaze.end.y - this.y, 2 ) );
            double heuristicThis = this.distance + dstToEndForThis;
            double heuristicObj = ( ( Tile ) o ).distance + dstToEndForObj;
            
            if ( heuristicThis - heuristicObj < 0 )
                return -1;
            else if ( heuristicThis - heuristicObj > 0 )
                return 1;
            else
                return 0;

        }
        return -1;
    }

    /**
     * A simple method to define whether the tile is valid or not 
     * (ie. not a block or on fire)
     */
    @Override
    public boolean isValid() {
        return (!super.isBlock) && (!this.isFire);
    }

    
}

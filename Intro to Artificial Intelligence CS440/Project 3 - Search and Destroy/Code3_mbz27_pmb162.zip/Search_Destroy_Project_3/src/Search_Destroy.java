import java.util.ArrayList;
import java.util.Random;

/**
 * Main program to run the program
 * @author Michael Zhang, Prasanth Balaji
 */
public class Search_Destroy {
    static int dimension;
    static Cell[][] environment;
    static Cell target;
    
    public static void main(String[] args) {
        if(args.length != 2) {
            System.out.println("Invalid Input!");
            return;
        }
        dimension = Integer.parseInt(args[0]);
        environment = genBoard(dimension);
        
        double avgAgent1 = 0, avgAgent2 = 0, avgImproved2 = 0, avgImproved1 = 0;
        int numSample = Integer.parseInt(args[1]);
        for(int i = 0; i < numSample; i++) {
            environment = genBoard(dimension);
            
            System.out.println("Agent 1");
            CellPerc[][] belief = genBelief(dimension);
            avgAgent1 += agent1(environment, belief);
            
            System.out.println("Agent 2");
            belief = genBelief(dimension);
            avgAgent2 += agent2(environment, belief);
            
            System.out.println("Improved Agent Based of % Found");
            belief = genBelief(dimension);
            avgImproved2 += improvedAgent2(environment, belief);
            
            System.out.println("Improved Agent Based of % Belief");
            belief = genBelief(dimension);
            avgImproved1 += improvedAgent1(environment, belief);
        }
        System.out.println(avgAgent1/numSample + " - Agent 1 || " + avgAgent2/numSample + " - Agent 2 || " + avgImproved2/numSample + " - Improved 2 || " + avgImproved1/numSample + " - Improved 1");
        
    }
    
    /**
     * The improved agent considers the largest probability in finding the target along the path towards the largest probability of finding the target on the map
     * @param env
     * @param belief
     * @return
     */
    public static double improvedAgent2(Cell[][] env, CellPerc[][] belief) {
        double distance = 0;
        double search = 0;
        CellPerc curr = belief[(int) Math.floor(Math.random()*env[0].length)][(int) Math.floor(Math.random()*env[0].length)];
        search++;
        
        System.out.println(curr.i + ", " + curr.j);
        
        if(env[curr.i][curr.j].getSucess()) {    
            return distance+search;
        }
        updateAgent2(belief, env[curr.i][curr.j]);
        
        while(true) {
            CellPerc temp = curr;
            curr = getLargestAgent2(belief, env[temp.i][temp.j]);
            
            CellPerc secLarge = getLargestPath2(environment, belief, temp, curr);
            if(secLarge == null) {
                // If the next location is itself (should be impossible)
                distance += (Math.abs(temp.i - curr.i) + Math.abs(temp.j - curr.j));
                search++;
                if(env[curr.i][curr.j].getSucess()) {
                    return distance+search;
                }
                updateAgent2(belief, env[curr.i][curr.j]);
            }else {
                // Next location is not itself
                distance += (Math.abs(temp.i - secLarge.i) + Math.abs(temp.j - secLarge.j));
                search++;
                if(env[secLarge.i][secLarge.j].getSucess()) {
                    return distance+search;
                }
                updateAgent2(belief, env[secLarge.i][secLarge.j]);
                distance += (Math.abs(secLarge.i - curr.i) + Math.abs(secLarge.j - curr.j));
                search++;
                
                if(env[curr.i][curr.j].getSucess()) {
                    return distance+search;
                }
                updateAgent2(belief, env[curr.i][curr.j]);
                
            }
            
        }
        
    }
    
    /**
     * Method to get the cell with the largest probability of finding the target along a path from the agent's position to the largest probability of finding the target
     * @param env
     * @param belief
     * @param agent
     * @param largest
     * @return
     */
    public static CellPerc getLargestPath2(Cell[][] env, CellPerc[][] belief, CellPerc agent, CellPerc largest) {
        ArrayList<CellPerc> path = new ArrayList<>();
        if(agent.j >= largest.j) {
            for(int i = agent.j; i >= largest.j; i--) {
                CellPerc ptr = belief[agent.i][i];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }else {
            for(int i = agent.j; i < largest.j; i++) {
                CellPerc ptr = belief[agent.i][i];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }
        if(agent.i >= largest.i) {
            for(int i = (agent.i); i >= largest.i; i--) {
                CellPerc ptr = belief[i][largest.j];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }else {
            for(int i = (agent.i); i < largest.i; i++) {
                CellPerc ptr = belief[i][largest.j];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }
        
        if(path.size() == 0) {
            // Largest and agent are the same location
            return null;
        }
        double secLarge = path.get(0).percentFound;
        for(CellPerc ptr : path) {
            if(secLarge < ptr.percentFound)
                secLarge = ptr.percentFound;
        }
        for(CellPerc ptr : path) {
            if(secLarge == ptr.percentFound)
                return ptr;
        }
        
        // Impossible
        return null;
    }
    
    /**
     * The improved agent considers the largest % belief along the path towards the largest % belief on the map
     * @param env
     * @param belief
     * @return
     */
    public static double improvedAgent1(Cell[][] env, CellPerc[][] belief) {
        double distance = 0;
        double search = 0;
        CellPerc curr = belief[(int) Math.floor(Math.random()*env[0].length)][(int) Math.floor(Math.random()*env[0].length)];
        search++;
        
        System.out.println(curr.i + ", " + curr.j);
        
        if(env[curr.i][curr.j].getSucess()) {    
            return distance+search;
        }
        updateAgent1(belief, env[curr.i][curr.j]);
        
        while(true) {
            CellPerc temp = curr;
            curr = getLargestAgent1(belief, env[temp.i][temp.j]);
            System.out.println(curr.i + ", " + curr.j);
            
            CellPerc secLarge = getLargestPath(environment, belief, temp, curr);
            if(secLarge == null) {
                // If the next location is itself (should be impossible)
                distance += (Math.abs(temp.i - curr.i) + Math.abs(temp.j - curr.j));
                search++;
                if(env[curr.i][curr.j].getSucess()) {
                    return distance+search;
                }
                updateAgent1(belief, env[curr.i][curr.j]);
            }else {
                // Next location is not itself
                distance += (Math.abs(temp.i - secLarge.i) + Math.abs(temp.j - secLarge.j));
                search++;
                if(env[secLarge.i][secLarge.j].getSucess()) {
                    return distance+search;
                }
                updateAgent1(belief, env[secLarge.i][secLarge.j]);
                distance += (Math.abs(secLarge.i - curr.i) + Math.abs(secLarge.j - curr.j));
                search++;
                if(env[curr.i][curr.j].getSucess()) {
                    return distance+search;
                }
                updateAgent1(belief, env[curr.i][curr.j]);
                
            }
            
        }
        
    }
    
    /**
     * Method to get the cell with the largest % belief along a path from the agent's position to the largest % belief on the map
     * @param env
     * @param belief
     * @param agent
     * @param largest
     * @return
     */
    public static CellPerc getLargestPath(Cell[][] env, CellPerc[][] belief, CellPerc agent, CellPerc largest) {
        ArrayList<CellPerc> path = new ArrayList<>();
        if(agent.j >= largest.j) {
            for(int i = agent.j; i >= largest.j; i--) {
                CellPerc ptr = belief[agent.i][i];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }else {
            for(int i = agent.j; i < largest.j; i++) {
                CellPerc ptr = belief[agent.i][i];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }
        if(agent.i >= largest.i) {
            for(int i = (agent.i); i >= largest.i; i--) {
                CellPerc ptr = belief[i][largest.j];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }else {
            for(int i = (agent.i); i < largest.i; i++) {
                CellPerc ptr = belief[i][largest.j];
                if(!(agent.i == largest.i && i == largest.j)) {
                    path.add(ptr);
                }
            }
        }
        if(path.size() == 0) {
            // Largest and agent are the same location
            return null;
        }
        double secLarge = path.get(0).percentBelief;
        for(CellPerc ptr : path) {
            if(secLarge < ptr.percentBelief)
                secLarge = ptr.percentBelief;
        }
        for(CellPerc ptr : path) {
            if(secLarge == ptr.percentBelief)
                return ptr;
        }
        
        // Impossible
        return null;
    }
    
    /**
     * Simple agent 1 that only searches cells with the largest % belief and repeatedly doing so until the target is found
     * @param env
     * @param belief
     * @return
     */
    public static double agent1(Cell[][] env, CellPerc[][] belief) {
        double distance = 0;
        double search = 0;
        CellPerc curr = belief[(int) Math.floor(Math.random()*env[0].length)][(int) Math.floor(Math.random()*env[0].length)];
        search++;
        
        
        if(env[curr.i][curr.j].getSucess()) {    
            return distance+search;
        }
        updateAgent1(belief, env[curr.i][curr.j]);
        
        while(true) {
            CellPerc temp = curr;
            curr = getLargestAgent1(belief, env[temp.i][temp.j]);
            
            distance += (Math.abs(temp.i - curr.i) + Math.abs(temp.j - curr.j));
            search++;
            if(env[curr.i][curr.j].getSucess()) {
                return distance+search;
            }
            updateAgent1(belief, env[curr.i][curr.j]);
            //return 1;
            
        }
        
    }
    
    /**
     * Simple agent 2 that only searches cells with the largest probability of finding the target and repeated doing so until the target is found
     * @param env
     * @param belief
     * @return
     */
    public static double agent2(Cell[][] env, CellPerc[][] belief) {
        double distance = 0;
        double search = 0;
        CellPerc curr = belief[(int) Math.floor(Math.random()*env[0].length)][(int) Math.floor(Math.random()*env[0].length)];
        search++;
        
        
        if(env[curr.i][curr.j].getSucess()) {    
            return distance+search;
        }
        updateAgent2(belief, env[curr.i][curr.j]);
        
        while(true) {
            CellPerc temp = curr;
            curr = getLargestAgent2(belief, env[temp.i][temp.j]);
            
            distance += (Math.abs(temp.i - curr.i) + Math.abs(temp.j - curr.j));
            search++;
            if(env[curr.i][curr.j].getSucess()) {
                return distance+search;
            }
            updateAgent2(belief, env[curr.i][curr.j]);
            //return 1;
            
        }
    }
    
    /**
     * Updates the percent belief of all cells on the map
     * @param belief
     * @param c1
     */
    public static void updateAgent1(CellPerc[][] belief, Cell c1) {
        double sanity = 0;
        double margin = ((1-belief[c1.i][c1.j].percentBelief) + (belief[c1.i][c1.j].percentBelief)*Search_Destroy.environment[c1.i][c1.j].getFalseNegRate());
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                if(!(c1.i == i && c1.j == j)) {
                    belief[i][j].percentBelief = (belief[i][j].percentBelief) / 
                            margin;
                    sanity += belief[i][j].percentBelief;
                }
                
            }
        }
        belief[c1.i][c1.j].percentBelief = (belief[c1.i][c1.j].percentBelief * c1.getFalseNegRate()) /
                margin;
        sanity += belief[c1.i][c1.j].percentBelief;
        System.out.println("Total Percent Belief: " + sanity);
        
        printBelief(belief);
    }
    
    /**
     * Updates the probability of find the target of all cells on the map
     * @param belief
     * @param c1
     */
    public static void updateAgent2(CellPerc[][] belief, Cell c1) {
        updateAgent1(belief, c1);
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                belief[i][j].percentFound = (1-Search_Destroy.environment[i][j].getFalseNegRate())*belief[i][j].percentBelief;
            }
        }
    }
    
    /**
     * Finds the closest cell with the largest % belief
     * @param belief
     * @param curr
     * @return
     */
    public static CellPerc getLargestAgent1(CellPerc[][] belief, Cell curr) {
        ArrayList<CellPerc> ties = new ArrayList<>();
        double largest = belief[0][0].percentBelief;
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                if(largest < belief[i][j].percentBelief) {
                    largest = belief[i][j].percentBelief;
                }
            }
        }
        
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                if(largest == belief[i][j].percentBelief) {
                    ties.add(belief[i][j]);
                }
            }
        }
        
        CellPerc result = ties.get(0);
        double smallest = Math.abs(curr.i - result.i) + Math.abs(curr.j - result.j);
        for(CellPerc ptr : ties) {
            if(smallest > Math.abs(curr.i - ptr.i) + Math.abs(curr.j - ptr.j)) {
                smallest = Math.abs(curr.i - ptr.i) + Math.abs(curr.j - ptr.j);
                result = ptr;
            }
        }
        return result;
        
    }
    
    /**
     * Finds the closest cell with the largest probability of find the target
     * @param belief
     * @param curr
     * @return
     */
    public static CellPerc getLargestAgent2(CellPerc[][] belief, Cell curr) {
        ArrayList<CellPerc> ties = new ArrayList<>();
        double largest = belief[0][0].percentFound;
        for(int i = 0; i < belief.length; i++) {
            for(int j = 0; j < belief.length; j++) {
                if(largest < belief[i][j].percentFound) {
                    largest = belief[i][j].percentFound;
                }
            }
        }
        
        for(int i = 0; i < belief.length; i++) {
            for(int j = 0; j < belief.length; j++) {
                if(largest == belief[i][j].percentFound) {
                    ties.add(belief[i][j]);
                }
            }
        }
        
        CellPerc result = ties.get(0);
        double smallest = Math.abs(curr.i - result.i) + Math.abs(curr.j - result.j);
        for(CellPerc ptr : ties) {
            if(smallest > Math.abs(curr.i - ptr.i) + Math.abs(curr.j - ptr.j)) {
                smallest = Math.abs(curr.i - ptr.i) + Math.abs(curr.j - ptr.j);
                result = ptr;
            }
        }
        return result;
        
    }
    
    /**
     * Method to generate board with random terrain types and selects a random target position
     * @param dimension
     * @return
     */
    private static Cell[][] genBoard(int dimension){
        Cell[][] result = new Cell[dimension][dimension];
        Random random = new Random();
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                int rand = random.nextInt(4);
                if(rand == 0) {
                    result[i][j] = new Cell("Flat", i, j);
                }else if(rand == 1) {
                    result[i][j] = new Cell("Hilly", i, j);
                }else if(rand == 2) {
                    result[i][j] = new Cell("Forested", i, j);
                }else {
                    result[i][j] = new Cell("Caves", i, j);
                }
            }
        }
        target = result[random.nextInt(dimension)][random.nextInt(dimension)];
        target.isTarget = true;
        
        return result;
    }
    
    /**
     * Initializes the belief of each cell
     * @param dimension
     * @return
     */
    private static CellPerc[][] genBelief(int dimension){
        CellPerc[][] result = new CellPerc[dimension][dimension];
        Random random = new Random();
        for(int i = 0; i < dimension; i++) {
            for(int j = 0; j < dimension; j++) {
                result[i][j] = new CellPerc(dimension, i, j);
            }
        }
        return result;
    }

    /**
     * Simple debugging method to print out the environment
     * @param env
     */
    private static void printEnvir(Cell[][] env) {
        for(int i = 0; i < env.length; i++) {
            for(int j = 0; j < env.length; j++) {
                System.out.print(env[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    /**
     * Simple debugging method to printout the % belief of each cell 
     * @param belief
     */
    private static void printBelief(CellPerc[][] belief) {
        for(int i = 0; i < belief.length; i++) {
            for(int j = 0; j < belief.length; j++) {
                System.out.print(belief[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("\n");
    }
    
}

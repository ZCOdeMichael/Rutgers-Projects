
/**
 * Object that stores the percent probability of finding the target and the belief that the target is in the cell (i, j)
 * @author Michael Zhang, Prasanth Balaji
 */
public class CellPerc {
    double percentBelief;
    double percentFound;
    int i, j;
    
    /**
     * Constructor
     * @param dimension
     * @param i
     * @param j
     */
    public CellPerc(int dimension, int i, int j) {
        this.percentBelief = 1.0/Math.pow((double)dimension, 2.0f);
        this.percentFound = 0;
        this.i = i;
        this.j = j;
    }
    
    /**
     * A simply method to print out the percent belief rounded to 4 decimals
     */
    public String toString() {
        return String.valueOf(Math.round((percentBelief*10000.0))/10000.0);
    }
}

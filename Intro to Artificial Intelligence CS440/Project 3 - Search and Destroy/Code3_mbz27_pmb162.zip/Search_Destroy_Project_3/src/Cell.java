
/**
 * Object that stores the terrain type and indicates if the cell contains the target
 * @author Michael Zhang, Prasanth Balaji
 */
public class Cell {
    String terrain;
    boolean isTarget;
    int i, j;
    public Cell(String terrain, int i, int j) {
        this.terrain = terrain;
        this.isTarget = false;
        this.i = i;
        this.j = j;
    }
    
    /**
     * Simple method to return the false negative rate for the terrain type
     * @return
     */
    public double getFalseNegRate() {
        if(terrain.equals("Flat")) {
            return 0.1;
        }else if(terrain.equals("Hilly")) {
            return 0.3;
        }else if(terrain.equals("Forested")) {
            return 0.7;
        }else {
            return 0.9;
        }
    }
    
    /**
     * Simple method to return if the target was successfully found
     * @return
     */
    public boolean getSucess() {
        if(isTarget) {
            if(Math.random() < getFalseNegRate()) {
                return false;
            }
            return true;
        }
        return false;
    }
    
    /**
     * Simple method to return the terrain type
     */
    public String toString() {
        switch(terrain) {
            case "Flat":
                return "FL";
            case "Hilly":
                return "HI";
            case "Forested":
                return "FO";
            default:
                return "CA";
        }
    }
    
}

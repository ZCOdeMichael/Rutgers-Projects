import java.util.ArrayList;
import java.util.HashSet;

/**
 * A class that stores a set of Cells and the total number of bombs in the set of Cells
 * which reprents a linear equation
 * @author Michael Zhang, Prasanth Balaji
 *
 */
public class Knowledge implements Cloneable {

    ArrayList<Cell> equation;
    int num_bombs;
    
    public Knowledge(ArrayList<Cell> equation, int num_bombs) {
        this.equation = equation;
        this.num_bombs = num_bombs;
    }
    
    /**
     * Simple equals method to compare two Knowledge objects
     */
    public boolean equals(Object o) {
        if(o instanceof Knowledge) {
            Knowledge curr = (Knowledge)o;
            if(curr.num_bombs != this.num_bombs) return false;
            if(this.equation.size() != curr.equation.size()) return false;
            for(Cell ptr : curr.equation) {
                if(!this.equation.contains(ptr))
                    return false;
            }
            return true;
            
        }
        return false;
    }
    
    /**
     * Simple toString to print out a description of the linear equation
     */
    public String toString() {
        String result = num_bombs + " = ";
        for(Cell ptr : equation) {
            result += "(" + ptr.x + ", " + ptr.y + ") + ";
        }
        return result;
    }
    
    /**
     * Method to clone the Knowledge object
     */
    public Object clone() {
        ArrayList<Cell> temp_equ = new ArrayList<>();
        for(Cell ptr : this.equation) {
            temp_equ.add((Cell)ptr.clone());
        }
        Knowledge result = new Knowledge(temp_equ, this.num_bombs);
        
        return result;
    }
}

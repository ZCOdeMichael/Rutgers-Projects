
/**
 * Simple class to store two different data types since java doesn't support Pairs 
 * (JavaFx does but it's kind of overkill to import an entire external library to just have the pair implementation)
 * @author Michael Zhang, Prasanth Balaji
 * 
 * @param <U>
 * @param <V>
 */
public class Pair<U, V>{
    U o1;
    V o2;
    public Pair(U o1, V o2) {
        this.o1 = o1;
        this.o2 = o2;
    }

}
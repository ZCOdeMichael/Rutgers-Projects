import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
/**
 * Main class to run the algorithm to solve the minesweeper 
 * @author Michael Zhang, Prasanth Balaji
 */
public class MineSweeper {

    static Cell minesweeper[][];
    static ArrayList<Knowledge> knowledge_base;
    static ArrayList<Cell> uncovered_cells;
    static ArrayList<Cell> adjacent_cells;
    static boolean improvedAgent, globalInformation;
    static int dimension;
    static int mines;
    static int num_exploded_mines;
    static int num_exploded_mines_chance;
    static int inferred_mines;
    static int inferred_safe;
    static int random_selection;
    
    public static void main(String[] args) {
        
        if(args.length != 4) {
            System.out.println("Invalid input!");
            return;
        }

        dimension = Integer.parseInt(args[0]);
        mines = Integer.parseInt(args[1]);
        if(Integer.parseInt(args[2]) == 1) {
            improvedAgent = true;
        }else {
            improvedAgent = false;
        }
        if(Integer.parseInt(args[3]) == 1) {
            globalInformation = true;
        }else {
            globalInformation = false;
        }
        
        
        uncovered_cells = new ArrayList<>();
        adjacent_cells = new ArrayList<>();
        knowledge_base = new ArrayList<>();
        num_exploded_mines = 0;
        num_exploded_mines_chance = 0;
        inferred_mines = 0;
        inferred_safe = 0;
        random_selection = 0;
        
        if(mines > Math.pow(dimension, 2)) {
            System.out.println("There are too many mines to place!");
            return;
        }
        if(mines == Math.pow(dimension, 2)) {
            System.out.println("Warning the entire board is comprised of bombs!");
        }
        
        
        
        minesweeper = genBoard(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        System.out.println("Player view of the board");
        printBoard_UserMode(minesweeper);
        System.out.println("The actual board");
        printBoard_AdminMode(minesweeper);
        
        if(globalInformation) {
            run_improved();
        }else {
            run();
        }
        
        System.out.println("\nFinal player view of the board");
        printBoard_UserMode(minesweeper);
        System.out.println("\nThe actual board");
        printBoard_AdminMode(minesweeper);
        System.out.println("The number of mines exploded: " + num_exploded_mines);
        System.out.println("% of mines exploded: " + (((double)num_exploded_mines)/mines * 100));
        System.out.println("Number of mines inferred: " + inferred_mines);
        System.out.println("Number of safe cells inferred: " + inferred_safe);
        System.out.println("Number of cells that are randomly selected: " + random_selection);
    }
    
    /**
     * Method to run the algorithm that will infer cells in the minesweeper board with the knowledge base
     */
    private static void run() {
        Cell curr = pickRandomSafe();
        if(curr == null) {
            return;
        }
        
        // When we uncovered all the cells on the board
        while(uncovered_cells.size() < Math.pow(dimension, 2)) {

            // Infer information from the current non-mine cell
            gatherInfo(curr, knowledge_base, minesweeper);
            
            // When there is no more to infer about the adjacent covered cells to the uncovered cells
            while(!isInconclusive(adjacent_cells)) {
                // Goes through all the adjacent covered cells
                for(int i = 0; i < adjacent_cells.size(); i++) {
                    Cell ptr = adjacent_cells.get(i);
                    
                    if(ptr.infer != 1) {
                        int currInfer = isMineInfer(ptr, knowledge_base);
                        if(currInfer == 1) {
                            // tile is a bomb
                            System.out.println(ptr + "\nIs a mine\n");
                            
                            ArrayList<Cell> temp_equation = new ArrayList<>();
                            ptr.infer = 1;
                            ptr.status = 0;
                            temp_equation.add(ptr);
                            
                            // adds it to the knowledge base
                            Knowledge temp_knowledge = new Knowledge(temp_equation, 1);
                            if(!knowledge_base.contains(temp_knowledge))
                                knowledge_base.add(temp_knowledge);
                            if(!uncovered_cells.contains(ptr))
                                uncovered_cells.add(ptr);
                            
                            
                            if(adjacent_cells.contains(ptr)) {
                                adjacent_cells.remove(ptr);
                            }
                            inferred_mines++;
                            
                            System.out.println();
                            printBoard_UserMode(minesweeper);
                            System.out.println();
                            i = -1;
                        }else if(currInfer == 0) {
                            // tile is not a bomb
                            System.out.println(ptr + "\nIs not a mine\n");
                            
                            // Infer information from the current non-mine cell
                            gatherInfo(ptr, knowledge_base, minesweeper);
                            
                            if(adjacent_cells.contains(ptr)) {
                                adjacent_cells.remove(ptr);
                            }
                            inferred_safe++;
                            
                            System.out.println();
                            printBoard_UserMode(minesweeper);
                            System.out.println();
                            i = -1;
                        }else if(currInfer == -1) {
                            // inconclusive
                            ptr.infer = -1;
                            System.out.println(ptr + "\nInconclusive\n");
                            
                        }else {
                            // Inconsistent Knowledge base
                            System.out.println(ptr + "\nKB Inconsistent\n");
                            return;
                        }
                    }
                    
                    
                }
            }
            
            curr = pickRandomSafe();
            resetInconclusive(adjacent_cells);
        }
        
    }
    
    /**
     * A slightly modified version of the run method to account for the global information added to the the knowledge base
     */
    private static void run_improved() {
        Cell curr = null;

        // When we uncovered all the cells on the board
        while(uncovered_cells.size() < Math.pow(dimension, 2)) {
            
            // When there is no more to infer about the adjacent covered cells to the uncovered cells
            while(!isInconclusive(adjacent_cells)) {
                // Goes through all the adjacent covered cells
                for(int i = 0; i < adjacent_cells.size(); i++) {
                    Cell ptr = adjacent_cells.get(i);
                    
                    if(ptr.infer != 1) {
                        int currInfer = isMineInfer(ptr, knowledge_base);
                        if(currInfer == 1) {
                            // tile is a bomb
                            System.out.println(ptr + "\nIs a mine\n");
                            
                            ArrayList<Cell> temp_equation = new ArrayList<>();
                            ptr.infer = 1;
                            ptr.status = 0;
                            temp_equation.add(ptr);
                            
                            // adds it to the knowledge base
                            Knowledge temp_knowledge = new Knowledge(temp_equation, 1);
                            if(!knowledge_base.contains(temp_knowledge))
                                knowledge_base.add(temp_knowledge);
                            if(!uncovered_cells.contains(ptr))
                                uncovered_cells.add(ptr);
                            
                            
                            if(adjacent_cells.contains(ptr)) {
                                adjacent_cells.remove(ptr);
                            }
                            inferred_mines++;
                            
                            System.out.println();
                            printBoard_UserMode(minesweeper);
                            System.out.println();
                            i = -1;
                        }else if(currInfer == 0) {
                            // tile is not a bomb
                            System.out.println(ptr + "\nIs not a mine\n");
                            
                            // Infer information from the current non-mine cell
                            gatherInfo(ptr, knowledge_base, minesweeper);
                            
                            if(adjacent_cells.contains(ptr)) {
                                adjacent_cells.remove(ptr);
                            }
                            inferred_safe++;
                            
                            System.out.println();
                            printBoard_UserMode(minesweeper);
                            System.out.println();
                            i = -1;
                        }else if(currInfer == -1) {
                            // inconclusive
                            ptr.infer = -1;
                            System.out.println(ptr + "\nInconclusive\n");
                            
                        }else {
                            // Inconsistent Knowledge base
                            System.out.println(ptr + "\nKB Inconsistent\n");
                            return;
                        }
                    }
                    
                    
                }
            }
            
            curr = pickRandomSafe();
            resetInconclusive(adjacent_cells);
            if(curr != null)
                gatherInfo(curr, knowledge_base, minesweeper);
        }

    }

    /**
     * A debugging method to print out the progress of the program
     * @param partial
     * @param full
     * @return
     */
    private static String loadingBar(int partial, int full) {
        int bar = partial / 20;
        int entire = full / 20;
        
        String load = "|";
        for(int i = 0; i < entire; i++) {
            if(i <= bar) {
                load += "=";
            }else {
                load += " ";
            }
        }
        load += "|\t" + (Math.round((((double)partial)/((double)full)*100*100))/100) + "%";
        return load;
    }
    
    /**
     * Checks if there are any more cells to infer information from
     * @param adjacent_cells
     * @return
     */
    private static boolean isInconclusive(ArrayList<Cell> adjacent_cells) {
        for(Cell ptr : adjacent_cells) {
            if(ptr.infer == 0) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Simply resets the infer flag
     * @param adjacent_cells
     */
    private static void resetInconclusive(ArrayList<Cell> adjacent_cells) {
        for(Cell ptr : adjacent_cells) {
            if(ptr.infer == -1) {
                ptr.infer = 0;
            }
        }
    }
    
    /**
     * Picks a safe cell that has not been uncovered and adds any mines that it picks
     * @return
     */
    public static Cell pickRandomSafe() {
        
        System.out.println("Picking random tile");
        
        Random random = new Random();
        Cell curr = minesweeper[random.nextInt(dimension)][random.nextInt(dimension)];
        while((curr.isBomb || uncovered_cells.contains(curr)) && uncovered_cells.size() != Math.pow(dimension, 2)) {
            
            if(curr.isBomb && !uncovered_cells.contains(curr)) {
                // Current is a bomb but has not been uncovered 
                num_exploded_mines++;
                num_exploded_mines_chance++;
                addMineToKB(curr, knowledge_base);
                uncovered_cells.add(curr);
                
                // Now we know that curr cell is a bomb no need to infer anything about it
                if(adjacent_cells.contains(curr)) {
                    adjacent_cells.remove(curr);
                }
                random_selection++;
                System.out.println("The randomly picked cell is a bomb!");
                printBoard_UserMode(minesweeper);
            }else {
                if(!curr.isBomb && !uncovered_cells.contains(curr)) {
                    // Current is not a bomb but has not been uncovered
                    
                    break;
                }
            }
            
            // If current is a bomb and has been uncovered or has not been uncovered - pick another random cell
            curr = minesweeper[random.nextInt(dimension)][random.nextInt(dimension)];
            
        }
        
        // If there is not cells left to pick from
        if(uncovered_cells.size() == Math.pow(dimension, 2)) {
            System.out.println("Failed to pick a random non-mine cell");
            return null;
        }
        
        // Successfully found a random Cell that is not a bomb and has not been uncovered
        System.out.println("Tile picked: " + curr);
        random_selection++;
        return curr;
    }
    
    /**
     * Simple method to add a mine to a the knowledge space
     * @param mine
     * @param kb
     */
    private static void addMineToKB(Cell mine, ArrayList<Knowledge> kb) {
        ArrayList<Cell> temp_equation = new ArrayList<>();
        mine.infer = 1;
        mine.status = 0;
        temp_equation.add(mine);
        Knowledge temp_knowledge = new Knowledge(temp_equation, 1);
        if(!kb.contains(temp_knowledge))
            kb.add(temp_knowledge);
        
    }
    
    /**
     * Given a specified tile this method will infer if the tile is a mine or not based of the knowledge base
     * using proof by contradiction
     * Returns 1 if specified tile is a bomb
     * Returns 0 if specified tile is not a bomb
     * Returns -1 if the kb is inconclusive
     * Returns -2 if the kb is inconsistent
     * @param tile
     * @param kb
     * @return
     */
    private static int isMineInfer(Cell tile, ArrayList<Knowledge> kb) {
        System.out.println("Inferring: " + tile);
        
        boolean isMine = true, isNotMine = true;
        
        if(improvedAgent) {
            
            for(int i = 0; i < kb.size(); i++) {
                Knowledge curr = kb.get(i);
                for(int j = 0; j < kb.size(); j++) {
                    if(j != i) {
                        if(isSubSet(curr, kb.get(j))) {
                            kb.get(j).num_bombs -= curr.num_bombs;
                            for(Cell ptr : curr.equation) {
                                kb.get(j).equation.remove(ptr);
                            }
                        }
                    }
                }
            }
            
        }
        
        
        // Copying knowledge base to perform inference operations on
        ArrayList<Knowledge> isBomb = new ArrayList<>();
        for(Knowledge ptr : kb) {
            isBomb.add((Knowledge)ptr.clone());
        }
        ArrayList<Knowledge> isNotBomb = new ArrayList<>();
        for(Knowledge ptr : kb) {
            isNotBomb.add((Knowledge)ptr.clone());
        }
        
        
        // Prove by contradiction
        // Assume tile is a bomb
        for(Knowledge ptr : isBomb) {
            if(ptr.equation.contains(tile)) {
                ptr.equation.remove(tile);
                ptr.num_bombs -= 1;
            }
            if(ptr.num_bombs > ptr.equation.size() || ptr.num_bombs < 0) {
                isMine = false;
                break;
            }
        }
        // Prove by contradiction
        // Assume tile is not a bomb
        for(Knowledge ptr : isNotBomb) {
            if(ptr.equation.contains(tile)) {
                ptr.equation.remove(tile);
            }
            if(ptr.num_bombs > ptr.equation.size() || ptr.num_bombs < 0) {
                isNotMine = false;
                break;
            }
        }
        
        
        if(!isMine && !isNotMine) {
            // Inconsistent KB
            return -2;
        }
        if(isMine && isNotMine) {
            // Inconclusive
            return -1;
        }
        if(!isMine && isNotMine) {
            // Cell is not a mine
            return 0;
        }
        if(isMine && !isNotMine) {
            // Cell is a mine
            return 1;
        }
        
        return -3; // Something terrible happened please don't let this ever happen
    }
    
    /**
     * Simple method to determine if the k1's equation is the subset of k2's equation
     * @param k1
     * @param k2
     * @return
     */
    private static boolean isSubSet(Knowledge k1, Knowledge k2) {
        if(k1.equation.size() >= k2.equation.size()) {
            return false;
        }
        for(Cell ptr : k1.equation) {
            if(!k2.equation.contains(ptr)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Method to gather/inferred information about the revealed tiles that are safe
     * @param tile
     * @param kb
     * @return
     */
    private static Pair<ArrayList<Knowledge>, Cell[][]> gatherInfo(Cell tile, ArrayList<Knowledge> kb, Cell[][] board) {
        
        uncovered_cells.add(tile);
        tile.status = 1;
        tile.infer = 1;
        
        // updates uncovered tile
        int uncovered_mines = 0, hidden_cells = 0, safe_cells = 0;
        
        for(int i = -1; i <= 1; i++) {
            for(int j = -1; j <= 1; j++) {
                if(isValidPos(tile.x+i, tile.y+j, board) && !(i == 0 && j == 0)) {
                    if(board[tile.x+i][tile.y+j].status == 0) uncovered_mines++;
                    if(board[tile.x+i][tile.y+j].status == -1) hidden_cells++;
                    if(board[tile.x+i][tile.y+j].status == 1) safe_cells++;
                }
            }
        }
        tile.num_safe_cells = safe_cells;
        tile.num_bomb_cells = uncovered_mines;
        tile.num_hidden_cells = hidden_cells;
        
        addSafe(tile, kb);
        boolean check = false;
        check = check_hidden_neighbor_mines(tile, kb, board);
        if(!check) {
            check = check_hidden_neighbor_safe(tile, kb, board);
        }
        if(!check && improvedAgent) {
            neighbor_mines(tile, kb, board);
        }
        // Add more inferences VVV
        
        return new Pair(kb, board);
    }
    
    /**
     * Simply adds a safe cell to the knowledge space
     * @param tile
     * @param kb
     */
    private static void addSafe(Cell tile, ArrayList<Knowledge> kb) {
        ArrayList<Cell> mine = new ArrayList<>();
        mine.add(tile);
        Knowledge temp = new Knowledge(mine, 0);
        if(!isDup(temp, kb)) {
            kb.add(temp);
        }
    }
    
    /**
     * Infers that the total # of mines in the surrounding hidden cells = the total number of bombs - the number of mines identified
     * @param tile
     * @param kb
     * @param board
     */
    private static void neighbor_mines(Cell tile, ArrayList<Knowledge> kb, Cell[][] board) {
        ArrayList<Cell> mines = new ArrayList<>();
        for(int i = -1; i <= 1; i++) {
            for(int j = -1; j <= 1; j++) {
                if(isValidPos(tile.x+i, tile.y+j, board) && !(i == 0 && j == 0)) {
                    if(board[tile.x+i][tile.y+j].status == -1) {
                        mines.add(board[tile.x+i][tile.y+j]);
                    }
                }
            }
        }
        if(mines.size() != 0) {
            Knowledge temp = new Knowledge(mines, tile.num_surrounding_bombs-tile.num_bomb_cells);
            if(!isDup(temp, kb)) {
                kb.add(temp);
            }
        }
    }
    
    /**
     * Infers that if the total # of mines - # of revealed mines = # of hidden neighbors than every hidden neighbor is a mine
     * @param tile
     * @param kb
     * @param board
     */
    private static boolean check_hidden_neighbor_mines(Cell tile, ArrayList<Knowledge> kb, Cell[][] board) {
        if(tile.num_surrounding_bombs - tile.num_bomb_cells == tile.num_hidden_cells) {
            
            for(int i = -1; i <= 1; i++) {
                for(int j = -1; j <= 1; j++) {
                    if(isValidPos(tile.x+i, tile.y+j, board) && !(i == 0 && j == 0)) {
                        if(board[tile.x+i][tile.y+j].status == -1) {
                            ArrayList<Cell> mine = new ArrayList<>();
                            mine.add(board[tile.x+i][tile.y+j]);
                            Knowledge temp = new Knowledge(mine, 1);
                            if(!isDup(temp, kb))
                                kb.add(temp);
                        }
                        
                    }
                }
            }
            return true;
            
        }
        return false;
    }
    
    /**
     * Infers that if the total # of safe neighbors - # of revealed safe neighbors = # of hidden neighbors than every hidden neighbor is safe
     * @param tile
     * @param kb
     * @param board
     */
    private static boolean check_hidden_neighbor_safe(Cell tile, ArrayList<Knowledge> kb, Cell[][] board) {
        if(((tile.num_safe_cells + tile.num_hidden_cells + tile.num_bomb_cells) - tile.num_surrounding_bombs) 
                - tile.num_safe_cells == tile.num_hidden_cells) {
            for(int i = -1; i <= 1; i++) {
                for(int j = -1; j <= 1; j++) {
                    if(isValidPos(tile.x+i, tile.y+j, board) && !(i == 0 && j == 0)) {
                        if(board[tile.x+i][tile.y+j].status == -1) {
                            ArrayList<Cell> mine = new ArrayList<>();
                            mine.add(board[tile.x+i][tile.y+j]);
                            Knowledge temp = new Knowledge(mine, 0);
                            if(!isDup(temp, kb))
                                kb.add(temp);
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    /**
     * Simple helper method to check for duplicates in the knowledge base
     * @param know
     * @param kb
     * @return
     */
    private static boolean isDup(Knowledge know, ArrayList<Knowledge> kb) {
        for(Knowledge ptr : kb) {
            if(ptr.equals(know))
                return true;
        }
        return false;
    }
    
    /**
     * Generates a Minesweeper board with dim x dim dimensions and num_mines mines
     * @param dim
     * @param num_mines
     * @return
     */
    private static Cell[][] genBoard(int dim, int num_mines) {
        Cell[][] board = new Cell[dim][dim];
        ArrayList<Cell> equation = new ArrayList<>();
        
        for(int i = 0; i < dim; i++) {
            for(int j = 0; j < dim; j++) {
                board[i][j] = new Cell(i, j, false);
                if(globalInformation) {
                    equation.add(board[i][j]);
                }
                adjacent_cells.add(board[i][j]);
            }
        }
        
        Random random = new Random();
        for(int i = 0; i < num_mines; i++) {
            Cell curr = board[random.nextInt(dim)][random.nextInt(dim)]; 
            if(curr.isBomb) {
                do {
                    curr = board[random.nextInt(dim)][random.nextInt(dim)];
                }while(curr.isBomb);
                curr.isBomb = true;
            }else {
                curr.isBomb = true;
            }
        }
        
        
        for(int i = 0; i < dim; i++) {
            for(int j = 0; j < dim; j++) {
                Cell curr = board[i][j];
                
                if(!curr.isBomb) {
                    int count_mine = 0;
                    for(int k = -1; k <= 1; k++) {
                        for(int l = -1; l <= 1; l++) {
                            int x = i+k, y = j+l;
                            
                            if(isValidPos(i+k, j+l, board) && !(k == 0 && l == 0)) {
                                if(board[i+k][j+l].isBomb) count_mine++;
                            }
                        }
                    }
                    
                    curr.num_surrounding_bombs = count_mine;
                }
                
            }
        }

        if(globalInformation) {
            Knowledge globalInfo = new Knowledge(equation, num_mines);
            knowledge_base.add(globalInfo);
        }
        
        return board;
        
    }
    
    
    /**
     * Prints out the board from the player's / algorithm's point of view
     * @param board
     */
    private static void printBoard_UserMode(Cell[][] board) {
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board.length; j++) {
                if(board[i][j].status == -1) {
                    System.out.print(" ?");
                }else if(board[i][j].status == 0) {
                    System.out.print(" X");
                }else {
                    System.out.print(" " + board[i][j].num_surrounding_bombs);
                }
            }
            System.out.println();
        }
    }
    
    /**
     * Prints out the actual board
     * @param board
     */
    
    private static void printBoard_AdminMode(Cell[][] board) {
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board.length; j++) {
                if(board[i][j].isBomb) {
                    System.out.print(" X");
                }else {
                    System.out.print(" " + board[i][j].num_surrounding_bombs);
                }
            }
            System.out.println();
        }
    }
    
    /**
     * Helper method to check if index is valid
     * @param i
     * @param j
     * @param board
     * @return
     */
    private static boolean isValidPos(int i, int j, Cell[][] board) {
        return !(i >= board[0].length || j >= board[0].length || i < 0 || j < 0);
    }
    
    
}

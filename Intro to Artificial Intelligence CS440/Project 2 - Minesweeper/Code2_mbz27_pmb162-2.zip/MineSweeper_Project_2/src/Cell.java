
/**
 * Class that contains all the information about the individual cells on the minesweeper board
 * @author Michael Zhang, Prasanth Balaji
 *
 */
public class Cell implements Cloneable {

    int status; // mine = 0, safe = 1, covered = -1
    int num_surrounding_bombs; // number of bombs around this cell (the clue that is given when uncovering a cell)
    int num_safe_cells; // number of identified safe cells around this cell
    int num_bomb_cells; // number of identified bomb cells around this cell
    int num_hidden_cells; // number of covered cells around this cell
    
    int infer; // conclusive = 1, inconclusive = -1, not set = 0
    
    boolean isBomb;
    int x, y;
    
    public Cell(int x, int y, boolean isBomb) {
        this.x = x;
        this.y = y;
        this.isBomb = isBomb;
        
        this.status = -1;
        
        // VV These values need to be set when generating the board
        this.num_surrounding_bombs = -1;
        this.num_safe_cells = -1;
        this.num_bomb_cells = -1;
        this.num_hidden_cells = -1;
        this.infer = 0;
    }
    
    /**
     * Simple equals method to compare two Cell objects
     */
    public boolean equals(Object o) {
        if(o instanceof Cell) {
            return (this.x == ((Cell)o).x) && (this.y == ((Cell)o).y); 
        }
        return false;
    }
    
    /**
     * Simple toString to print out a description of the cell
     */
    public String toString() {
        if(this.isBomb) {
            return "Cord: " + x + ", " + y + " | status: " + convertStatus() + " | This is a mine";
        }
        return "Cord: " + x + ", " + y + " | status: " + convertStatus() + " | Bombs around cell: " + num_surrounding_bombs;
    }
    
    /**
     * Simple helper method to convert the status number into a human readable description
     * @return
     */
    private String convertStatus() {
        if(status == 0) {
            return "mine";
        }else if(status == 1) {
            return "safe";
        }else {
            return "covered";
        }
    }
    
    /**
     * Method to clone the Cell object
     */
    public Object clone() {
        Cell result = new Cell(this.x, this.y, this.isBomb);
        
        result.status = this.status;
        result.num_surrounding_bombs = this.num_surrounding_bombs;
        result.num_safe_cells = this.num_safe_cells;
        result.num_bomb_cells = this.num_bomb_cells;
        result.num_hidden_cells = this.num_hidden_cells;
        result.infer = this.infer;
        
        return result;
    }
    
}

package application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ImprovedAgentSoftClass {

    private static double LEARNING_RATE = .001;
    
    public RGBWrapper[][] runImproved(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[][] ogImage, RGBWrapper[] centers, double[][] wts){
        RGBWrapper[][] result = new RGBWrapper[greyImage[0].length][greyImage.length];
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = 0; x < greyImage.length/2; x++) {
                result[x][y] = new RGBWrapper(clusterImage[x][y].red, clusterImage[x][y].green, clusterImage[x][y].blue, clusterImage[x][y].x, clusterImage[x][y].y);
            }
        }
        double weights[][] = null;
        if(wts == null) {
            weights = training(greyImage, clusterImage, centers);
        }else {
            weights = wts;
        }
        
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = 0; x < greyImage.length; x++) {
                if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == (greyImage.length-1)) {
                    result[x][y] = new RGBWrapper(0, 0, 0, x, y);
                }else {
                    double[] grey = new double[10+45];
                    grey[0] = 1;
                    int count = 1;
                    for(int i = -1; i <= 1; i++) {
                        for(int j = 1; j >= -1; j--) {
                            grey[count] = ((double)greyImage[x + i][y + j].red) / 255.0;
                            count++;
                        }
                    }
                    
                    for(int k = 1; k <= 9; k++) {
                        for(int l = k; l <= 9; l++) {
                            grey[count] = grey[k]*grey[l];
                            count++;
                        }
                    }
                    
                    double largest = fnc(weights, grey, 0);
                    int choose = 0;
                    for(int i = 0; i < centers.length; i++) {
                        double curr = fnc(weights, grey, i);
                        if(largest < curr) {
                            choose = i;
                            largest = curr;
                        }
                    }
                    result[x][y] = new RGBWrapper(centers[choose].red, centers[choose].green, centers[choose].blue, x, y);
                    
                }
            }    
        }
        return result;
        
    }
    
    public double[][] training(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[] centers){
        double weights[][] = new double[centers.length][10+45];
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                double weight = Math.random();
                while(weight == 0 || weight == 1) {
                    weight = Math.random();
                }
                weights[i][j] = weight;
            }
        }
        
        double loss = 0;
        int it = 0;
        do {
      
            RGBWrapper curr = greyImage[(int)(Math.random()*((greyImage.length/2) - 2) + 1)][(int)(Math.random()*(greyImage[0].length - 2) + 1)];
            double[] grey = new double[10+45];
            grey[0] = 1;
            int count = 1;
            for(int x = -1; x <= 1; x++) {
                for(int y = 1; y >= -1; y--) {
                    grey[count] = ((double)greyImage[curr.x + x][curr.y + y].red) / 255.0;
                    count++;
                }
            }
            
            for(int k = 1; k <= 9; k++) {
                for(int l = k; l <= 9; l++) {
                    grey[count] = grey[k]*grey[l];
                    count++;
                }
            }
            
            
            int Y[] = new int[centers.length];
            for(int i = 0; i < Y.length; i++) {
                if(centers[i].red == clusterImage[curr.x][curr.y].red && 
                    centers[i].green == clusterImage[curr.x][curr.y].green && 
                    centers[i].blue == clusterImage[curr.x][curr.y].blue) {
                    Y[i] = 1;
                }else {
                    Y[i] = 0;
                }
            }

            for(int i = 0; i < weights.length; i++) {
                
                double fn = fnc(weights, grey, i);
                for(int j = 0; j < weights[0].length; j++) {
                    weights[i][j] = weights[i][j] - LEARNING_RATE*(fn - Y[i])*grey[j];
                    
                }
                
            }
            
            
            loss = loss(weights, clusterImage, greyImage, centers);
            
            if(it % 1000 == 0) {
                System.out.println("Loss - " + loss);
                /*
                try {
                    saveData(loss, weights);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }*/
                
            }
            it++;
        }while(loss > 5800);
         
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                System.out.print(weights[i][j] + " ");
            }
            System.out.println();
        }
        
        return weights;
    }
    
    private void saveData(double loss, double[][] weights) throws IOException {
        FileWriter sl = new FileWriter("C:\\Users\\Family's RGB PGC\\git\\Intro-to-AI-CS440\\Colorizing_Project_4\\src\\LossValue", true);
        sl.write(loss + ",\n");
        
        /*
        FileWriter w = new FileWriter("C:\\Users\\Family's RGB PGC\\git\\Intro-to-AI-CS440\\Colorizing_Project_4\\src\\Weights", false);
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                w.write(weights[i][j] + " ");
            }
            w.write("\n");
        }
        w.close();
        */
        sl.close();
    }
    
    private double loss(double[][] weights, RGBWrapper[][] clusterImage, RGBWrapper[][] greyImage, RGBWrapper[] centers) {
        double result = 0;
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = 0; x < greyImage.length/2; x++) {
                if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == ((greyImage.length/2)-1)) {}
                else {
                    RGBWrapper curr = clusterImage[x][y];
                    int Y[] = new int[centers.length];
                    for(int i = 0; i < Y.length; i++) {
                        if(centers[i].red == curr.red && centers[i].green == curr.green && centers[i].blue == curr.blue) {
                            Y[i] = 1;
                        }else {
                            Y[i] = 0;
                        }
                    }
                    
                    double[] grey = new double[10+45];
                    grey[0] = 1;
                    int count = 1;
                    for(int i = -1; i <= 1; i++) {
                        for(int j = 1; j >= -1; j--) {
                            grey[count] = ((double)greyImage[curr.x + i][curr.y + j].red) / 255.0;
                            count++;
                        }
                    }
                    
                    for(int k = 1; k <= 9; k++) {
                        for(int l = k; l <= 9; l++) {
                            grey[count] = grey[k]*grey[l];
                            count++;
                        }
                    }
                    
                    for(int k = 0; k < centers.length; k++) {
                        result += -1*Y[k]*Math.log(fnc(weights, grey, k));
                    }
                }
            }
        }
        return result;
    }
    
    private double fnc(double[][] weights, double[] grey, int c) {
        double dot = dotProd(weights[c], grey);
        double fn = Math.exp(dot), denom = 0;
        for(int k = 0; k < weights.length; k++) {
            denom += Math.exp(dotProd(weights[k], grey));
        }
        fn = fn / denom;
        return fn;
    }
    
    private double dotProd(double[] weights, double[] grey) {
        double result = 0;
        for(int i = 0; i < grey.length; i++) {
            result += weights[i]*grey[i];
        }
        return result;
    }
}

package application;

public class ImprovedAgent {

    private final static int NUM_ITERATIONS = 20;
    private final static int BATCH_SIZE = 900000;
    private final static double LEARNING_RATE = .00001;
    private final static int NUM_DIM = 10;
    public RGBWrapper[][] runImproved(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[][] ogImage, RGBWrapper[] centers, double[][] wts) {
        RGBWrapper[][] result = new RGBWrapper[greyImage[0].length][greyImage.length];
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = 0; x < greyImage.length/2; x++) {
                result[x][y] = new RGBWrapper(ogImage[x][y].red, ogImage[x][y].green, ogImage[x][y].blue, x, y);
            }
        }
        
        double weights[][] = training(greyImage, ogImage, wts);
        
        
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = greyImage.length/2; x < greyImage.length; x++) {
                if(y == 0 || y == (greyImage[0].length-1) || x == (greyImage.length/2) || x == (greyImage.length-1)) {
                    result[x][y] = new RGBWrapper(0, 0, 0, x, y);
                }else {
                    int[] grey = new int[10];
                    grey[0] = 1;
                    int count = 1;
                    for(int i = -1; i <= 1; i++) {
                        for(int j = 1; j >= -1; j--) {
                            grey[count] = greyImage[x + i][y + j].red;
                            count++;
                        }
                    }
                    result[x][y] = new RGBWrapper((int)fwn(weights[0], grey), (int)fwn(weights[1], grey), (int)fwn(weights[2], grey), x, y);
                    
                }
            }
        }
        
        
        return result;
    }
    
    public double[][] training(RGBWrapper[][] greyImage, RGBWrapper[][] ogImage, double[][] wts) {
        //int temp = NUM_DIM+45;
        double[][] weights = new double[3][NUM_DIM];
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                weights[i][j] = Math.random();
            }
        }
        
        //double[] loss = loss(weights, ogImage, greyImage);
        
        for(int i = 0; i < NUM_ITERATIONS; i++) {
            for(int j = 0; j < BATCH_SIZE; j++) {
            //while(loss[0] > 20000000) {
             RGBWrapper curr = greyImage[(int)(Math.random()*((greyImage.length/2) - 2) + 1)][(int)(Math.random()*(greyImage[0].length - 2) + 1)];
            int[] grey = new int[NUM_DIM];
                grey[0] = 1;
                int count = 1;
                for(int x = -1; x <= 1; x++) {
                    for(int y = 1; y >= -1; y--) {
                        grey[count] = greyImage[curr.x + x][curr.y + y].red;
                        count++;
                    }
                }
                /*
                for(int k = 1; k <= 9; k++) {
                    for(int l = k; l <= 9; l++) {
                        grey[count] = grey[k]*grey[l];
                        count++;
                    }
                }
                */
                double fnValR = fwn(weights[0], grey);
                double fnValG = fwn(weights[1], grey);
                double fnValB = fwn(weights[2], grey);
                
                for(int k = 0; k < weights[0].length; k++) {
                    
                    weights[0][k] -= LEARNING_RATE*2*(fnValR - ogImage[curr.x][curr.y].red)*( (255*grey[k]*Math.exp(-1*grey[k]*weights[0][k])) / Math.pow((Math.exp(-1*grey[k]*weights[0][k]) + 1),2) );
                    weights[1][k] -= LEARNING_RATE*2*(fnValG - ogImage[curr.x][curr.y].green)*( (255*grey[k]*Math.exp(-1*grey[k]*weights[1][k])) / Math.pow((Math.exp(-1*grey[k]*weights[1][k]) + 1),2) );
                    weights[2][k] -= LEARNING_RATE*2*(fnValB - ogImage[curr.x][curr.y].blue)*( (255*grey[k]*Math.exp(-1*grey[k]*weights[2][k])) / Math.pow((Math.exp(-1*grey[k]*weights[2][k]) + 1),2) );
                    
                    /*
                    weights[0][k] -= LEARNING_RATE*2*(fnValR - ogImage[curr.x][curr.y].red)*( 255*(grey[k] / (2*Math.cosh(grey[k]*weights[0][k])+2)) );
                    weights[1][k] -= LEARNING_RATE*2*(fnValG - ogImage[curr.x][curr.y].green)*( 255*(grey[k] / (2*Math.cosh(grey[k]*weights[1][k])+2)) );
                    weights[2][k] -= LEARNING_RATE*2*(fnValB - ogImage[curr.x][curr.y].blue)*( 255*(grey[k] / (2*Math.cosh(grey[k]*weights[2][k])+2)) );
                    */
                    /*
                    weights[0][k] -= LEARNING_RATE*( (510*grey[k]*fnValR*((ogImage[curr.x][curr.y].red-255)*fnValR+ogImage[curr.x][curr.y].red)) / Math.pow((fnValR+1), 3) );
                    weights[1][k] -= LEARNING_RATE*( (510*grey[k]*fnValG*((ogImage[curr.x][curr.y].green-255)*fnValG+ogImage[curr.x][curr.y].green)) / Math.pow((fnValG+1), 3) );
                    weights[2][k] -= LEARNING_RATE*( (510*grey[k]*fnValB*((ogImage[curr.x][curr.y].blue-255)*fnValB+ogImage[curr.x][curr.y].blue)) / Math.pow((fnValB+1), 3) );
                    */
                }
                
                //loss = loss(weights, ogImage, greyImage);
                //System.out.println(loss[0]);
            //}
                //System.out.println("Red Loss - " + (fnValR - clusterImage[curr.x][curr.y].red) + " FnVal - " + fnValR + " RealVal - " + clusterImage[curr.x][curr.y].red);
                //System.out.println("Green Loss - " + (fnValG - clusterImage[curr.x][curr.y].green) + " FnVal - " + fnValG + " RealVal - " + clusterImage[curr.x][curr.y].green);
                //System.out.println("Blue Loss - " + (fnValB - clusterImage[curr.x][curr.y].blue) + " FnVal - " + fnValB + " RealVal - " + clusterImage[curr.x][curr.y].blue);
                //System.out.println();
                
            }
            double[] loss = loss(weights, ogImage, greyImage);
            for(double ptr : loss) {
                System.out.println(ptr);
            }
            System.out.println();
            
            
        }
        
        
        
        
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                System.out.print(weights[i][j] + " ");
            }
            System.out.println();
        }
        
        return weights;
        
    }
    
    private double fwn(double[] weights, int[] grey) {
        double result = 0;
        
        for(int i = 0; i < grey.length; i++) {
            result += weights[i]*((double)grey[i]);
        }
        

        result = ((double)(Math.exp(-1.0*result)+1.0));
        result = 1.0 / result;
        result *= 255;
        
        return result;
    }
    
    private double[] loss(double[][] weights, RGBWrapper[][] ogImage, RGBWrapper[][] greyImage) {
        double result[] = new double[3];
        for(int y = 0; y < greyImage[0].length; y++) {
            for(int x = 0; x < greyImage.length/2; x++) {
                if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == ((greyImage.length/2)-1)) {}
                else {
                    int[] grey = new int[10];
                    grey[0] = 1;
                    int count = 1;
                    for(int i = -1; i <= 1; i++) {
                        for(int j = 1; j >= -1; j--) {
                            grey[count] = greyImage[x + i][y + j].red;
                            count++;
                        }
                    }
                    
                    result[0] += Math.pow((fwn(weights[0], grey) - ogImage[x][y].red), 2);
                    result[1] += Math.pow((fwn(weights[1], grey) - ogImage[x][y].green), 2);
                    result[2] += Math.pow((fwn(weights[2], grey) - ogImage[x][y].blue), 2);
                }
            }
        }
        
        return result;
    }
        
}

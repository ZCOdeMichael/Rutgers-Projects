package application;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class BasicAgent {

    private BufferedImage image;
    private RGBWrapper imageValue[][];
    final static int NUM_MATCHES = 6;
    final static int NUM_THREADS = 10;
    final static boolean THREADED = false;
    
    public BasicAgent(BufferedImage img) {
        this.image = img;
        imageValue = new RGBWrapper[img.getHeight()][img.getWidth()];
        
    }
    
    public ArrayList<ArrayList<RGBWrapper>> cluster(int iterations, RGBWrapper centers[], int numClusters) {
        ArrayList<ArrayList<RGBWrapper>> clusters = new ArrayList<>();
        for(int i = 0; i < numClusters; i++) {
            clusters.add(new ArrayList<RGBWrapper>());
        }
        
        
        for(int i = 0; i < numClusters; i++) {
            centers[i] = new RGBWrapper((int)(Math.random()*255), (int)(Math.random()*255), (int)(Math.random()*255), 0, 0);
        }
        
        for(int it = 0; it < iterations; it++) {
            for(int i = 0; i < numClusters; i++) { // Resets all cluster groups for next iteration
                clusters.get(i).clear();
            }
            
            for(int y = 0; y < image.getHeight(); y++) {
                for(int x = 0; x < image.getWidth(); x++) {
                    ColorWrapper cw = new ColorWrapper(image.getRGB(x, y));
                    RGBWrapper curr = new RGBWrapper(cw.getRed(), cw.getGreen(), cw.getBlue(), x, y);
                    
                    // Finds the closest center from the current pixel color
                    double closest = Math.sqrt((Math.pow((curr.red)-(centers[0].red), 2)) + 
                            (Math.pow((curr.green)-(centers[0].green), 2)) + 
                            (Math.pow((curr.blue)-(centers[0].blue), 2)));
                    int closeCluster = 0;
                    for(int i = 0; i < numClusters; i++) {
                        double tempVal = Math.sqrt((Math.pow((curr.red)-(centers[i].red), 2)) + 
                                (Math.pow((curr.green)-(centers[i].green), 2)) + 
                                (Math.pow((curr.blue)-(centers[i].blue), 2)));
                        if(closest > tempVal) {
                            closest = tempVal;
                            closeCluster = i;
                        }
                    }
                    
                    // Adds the pixel to the closest cluster
                    clusters.get(closeCluster).add(curr);
                    
                }
            }
            
            for(int i = 0; i < numClusters; i++) {
                // Averages all values 
                double redAvg = 0, greenAvg = 0 , blueAvg = 0;
                for(RGBWrapper ptr : clusters.get(i)) {
                    redAvg += ptr.red;
                    greenAvg += ptr.green;
                    blueAvg += ptr.blue;
                }
                redAvg /= clusters.get(i).size();
                greenAvg /= clusters.get(i).size();
                blueAvg /= clusters.get(i).size();
                
                // Updates the centers of the clusters
                centers[i].red = (int)redAvg;
                centers[i].green = (int)greenAvg;
                centers[i].blue = (int)blueAvg;
            }
            
        }
        
        return clusters;
    }
    
    public RGBWrapper[][] run(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[][] ogImage, RGBWrapper[] centers) throws InterruptedException{
        RGBWrapper[][] result = new RGBWrapper[greyImage[0].length][greyImage.length];
        
        if(!THREADED) {
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = 0; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == (greyImage.length-1)) {
                        result[x][y] = new RGBWrapper(0, 0, 0, x, y);
                    }else {
                        RGBWrapper curr = new RGBWrapper(greyImage[x][y].red, greyImage[x][y].green, greyImage[x][y].blue, x, y);
                        result[x][y] = map(greyImage, clusterImage, centers, curr);
                    }
                    loadingBar(y, greyImage[0].length);
                }
            }
        }else {
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = greyImage.length/2; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == (greyImage.length/2) || x == (greyImage.length-1)) {
                        result[x][y] = new RGBWrapper(0, 0, 0, x, y);
                    }
                }
            }
        
            ArrayList<Thread> joinT = new ArrayList<>();
            for(int y = 0; y < greyImage[0].length; y+=(greyImage[0].length/NUM_THREADS)) {
                System.out.println(y);
                BasicAgentRun bgr = new BasicAgentRun(greyImage, clusterImage, centers, result, y);
                Thread temp = new Thread(bgr);
                temp.start();
                joinT.add(temp);
            
            }
            
            for(Thread ptr : joinT) {
                ptr.join();
            }
        }
        return result;
    }

    
    private void loadingBar(int y, int length) {
        String load = "";
        int scaleY = y / 10;
        int scaleLength = length /10;
        for(int i = 0; i < scaleLength; i++) {
            if(i < scaleY) {
                load += "=";
            }else {
                load += "-";
            }
        }
        System.out.println("\n\n\n\n\n\n\n\n\n\n" + load);
    }
    
    private RGBWrapper map(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[] centers, RGBWrapper curr) {
        ArrayList<RGBWrapper> smallest = new ArrayList<>();
        for(int i = 0; i < NUM_MATCHES; i++) {
            double closest = Double.MAX_VALUE;
            RGBWrapper temp = null;
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = 0; x < greyImage.length/2; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == ((greyImage.length/2)-1)) {}
                    else {
                        double currClosest = 
                                Math.sqrt(Math.pow((greyImage[curr.x-1][curr.y-1].red - greyImage[x-1][y-1].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y-1].red - greyImage[x][y-1].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y-1].red - greyImage[x+1][y-1].red), 2) +
                                
                                Math.pow((greyImage[curr.x-1][curr.y].red - greyImage[x-1][y].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y].red - greyImage[x][y].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y].red - greyImage[x+1][y].red), 2) +
                                
                                Math.pow((greyImage[curr.x-1][curr.y+1].red - greyImage[x-1][y+1].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y+1].red - greyImage[x][y+1].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y+1].red - greyImage[x+1][y+1].red), 2));
                        if(currClosest < closest) {
                            boolean inSmallest = false;
                            for(RGBWrapper ptr : smallest) {
                                if(ptr.x == x && ptr.y == y) {
                                    inSmallest = true;
                                    break;
                                }
                            }
                            if(!inSmallest) {
                                temp = new RGBWrapper(clusterImage[x][y].red, clusterImage[x][y].green, clusterImage[x][y].blue, x, y);
                                closest = currClosest;
                            }
                        }
                    }
                }
            }
            smallest.add(temp);
        }
        
        ArrayList<Integer> dupes = new ArrayList<>();
        int count[] = new int[SampleController.NUM_CLUSTERS];
        for(int i = 0; i < SampleController.NUM_CLUSTERS; i++) {
            RGBWrapper check = centers[i];
            for(RGBWrapper ptr : smallest) {
                if(ptr.red == check.red && ptr.green == check.green && ptr.blue == check.blue) {
                    count[i]++;
                }
            }
        }
        int largest = count[0];
        for(int ptr : count) {
            if(largest < ptr) {
                largest = ptr;
            }
        }
        
        for(int i = 0; i < SampleController.NUM_CLUSTERS; i++) {
            if(largest == count[i]) {
                dupes.add(i);
            }
        }
        
        if(dupes.size() != 1) {
            return smallest.get(0);
        }else {
            return new RGBWrapper(centers[dupes.get(0)].red, centers[dupes.get(0)].green, centers[dupes.get(0)].blue, curr.x, curr.y);
        }
        
    }
}

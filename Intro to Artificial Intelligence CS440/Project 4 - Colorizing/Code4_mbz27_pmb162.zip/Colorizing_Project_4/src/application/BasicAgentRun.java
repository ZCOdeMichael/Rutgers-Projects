package application;

import java.util.ArrayList;

public class BasicAgentRun implements Runnable {
    
    private RGBWrapper[][] greyImage, clusterImage, result;
    private RGBWrapper[] centers;
    private int y;
    
    public BasicAgentRun(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, 
            RGBWrapper[] centers, RGBWrapper[][] result, int y) {
        this.greyImage = greyImage;
        this.clusterImage = clusterImage;
        this.result = result;
        this.centers = centers;
        this.y = y;
    }
    
    @Override
    public void run() {
        for(int i = y; i < (y+(greyImage[0].length/BasicAgent.NUM_THREADS)); i++) {
            if(i >= greyImage[0].length) {
                break;
            }
            for(int x = greyImage.length/2; x < greyImage.length; x++) {
                if(i == 0 || i == (greyImage[0].length-1) || x == (greyImage.length/2) || x == (greyImage.length-1)) {
                }else {
                    RGBWrapper curr = new RGBWrapper(greyImage[x][i].red, greyImage[x][i].green, greyImage[x][i].blue, x, i);
                    result[x][i] = map(greyImage, clusterImage, centers, curr);
                }
            }
        }
        
    }
    
    private RGBWrapper map(RGBWrapper[][] greyImage, RGBWrapper[][] clusterImage, RGBWrapper[] centers, RGBWrapper curr) {
        ArrayList<RGBWrapper> smallest = new ArrayList<>();
        for(int i = 0; i < BasicAgent.NUM_MATCHES; i++) {
            double closest = Double.MAX_VALUE;
            RGBWrapper temp = new RGBWrapper(256, 256, 256, 0, 0);
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = 0; x < greyImage.length/2; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == ((greyImage.length/2)-1)) {}
                    else {
                        double currClosest = 
                                Math.sqrt(Math.pow((greyImage[curr.x-1][curr.y-1].red - greyImage[x-1][y-1].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y-1].red - greyImage[x][y-1].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y-1].red - greyImage[x+1][y-1].red), 2) +
                                
                                Math.pow((greyImage[curr.x-1][curr.y].red - greyImage[x-1][y].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y].red - greyImage[x][y].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y].red - greyImage[x+1][y].red), 2) +
                                
                                Math.pow((greyImage[curr.x-1][curr.y+1].red - greyImage[x-1][y+1].red), 2) +
                                Math.pow((greyImage[curr.x][curr.y+1].red - greyImage[x][y+1].red), 2) +
                                Math.pow((greyImage[curr.x+1][curr.y+1].red - greyImage[x+1][y+1].red), 2));
                        if(currClosest < closest) {
                            boolean inSmallest = false;
                            for(RGBWrapper ptr : smallest) {
                                if(ptr.x == x && ptr.y == y) {
                                    inSmallest = true;
                                    break;
                                }
                            }
                            if(!inSmallest) {
                                temp = new RGBWrapper(clusterImage[x][y].red, clusterImage[x][y].green, clusterImage[x][y].blue, x, y);
                                closest = currClosest;
                            }
                        }
                    }
                }
            }
            smallest.add(temp);
        }
        
        ArrayList<Integer> dupes = new ArrayList<>();
        int count[] = new int[SampleController.NUM_CLUSTERS];
        for(int i = 0; i < SampleController.NUM_CLUSTERS; i++) {
            RGBWrapper check = centers[i];
            for(RGBWrapper ptr : smallest) {
                if(ptr.red == check.red && ptr.green == check.green && ptr.blue == check.blue) {
                    count[i]++;
                }
            }
        }
        int largest = count[0];
        for(int ptr : count) {
            if(largest < ptr) {
                largest = ptr;
            }
        }
        
        for(int i = 0; i < SampleController.NUM_CLUSTERS; i++) {
            if(largest == count[i]) {
                dupes.add(i);
            }
        }
        
        if(dupes.size() != 1) {
            return smallest.get(0);
        }else {
            return new RGBWrapper(centers[dupes.get(0)].red, centers[dupes.get(0)].green, centers[dupes.get(0)].blue, curr.x, curr.y);
        }
        
    }


}

package application;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class SampleController {
    
    final static int NUM_CLUSTERS = 5;
    private final static int CLUSTER_ITERATIONS = 100;
    private BasicAgent ba;
    private RGBWrapper centers[];
    
    private RGBWrapper selected[][];
    private RGBWrapper ogImage[][];
    private RGBWrapper greyImage[][];
    private RGBWrapper clusterImage[][];
    private RGBWrapper basicAgent[][];
    private RGBWrapper improvedAgent[][];
    private double scale;
    
    private boolean basicAgentRun, improvedAgentRun;
    
    private BufferedImage OGimage;
    
    @FXML
    private Canvas canvas;

    @FXML
    private Slider zoom;

    private void drawSelected() {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        for(int y = 0; y < OGimage.getHeight(); y++) {
            for(int x = 0; x < OGimage.getWidth(); x++) {
                if(selected[x][y] != null) {
                    gc.setStroke(Color.rgb(selected[x][y].red, selected[x][y].green, selected[x][y].blue));
                    gc.strokeLine(x*scale, y*scale, x*scale, y*scale);
                }
            }
        }
    }
    
    @FXML
    void onClear(ActionEvent event) {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @FXML
    void onColor(ActionEvent event) {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        selected = ogImage;
        drawSelected();
    }

    @FXML
    void onImport(ActionEvent event) throws IOException {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open Source File for the Import");
        chooser.getExtensionFilters().addAll(new ExtensionFilter("Text Files", "*.jpg"),
                new ExtensionFilter("All Files", "*.*"));
        Stage stage = new Stage();
        File sourceFile = chooser.showOpenDialog(stage); //get the reference of the source file
        if(sourceFile == null) {
            return;
        }
        
        OGimage = ImageIO.read(sourceFile);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        for(int y = 0; y < OGimage.getHeight(); y++) {
            for(int x = 0; x < OGimage.getWidth(); x++) {
                ColorWrapper cw = new ColorWrapper(OGimage.getRGB(x, y));
                gc.setStroke(Color.rgb(cw.getRed(), cw.getGreen(), cw.getBlue()));
                gc.strokeLine(x, y, x, y);
            }
        }
        
        ogImage = new RGBWrapper[OGimage.getHeight()][OGimage.getWidth()];
        for(int y = 0; y < OGimage.getHeight(); y++) {
            for(int x = 0; x < OGimage.getWidth(); x++) {
                ColorWrapper cw = new ColorWrapper(OGimage.getRGB(x, y));
                ogImage[x][y] = new RGBWrapper(cw.getRed(), cw.getGreen(), cw.getBlue(), x, y);
            }
        }
        
        greyImage = new RGBWrapper[OGimage.getHeight()][OGimage.getWidth()];
        for(int y = 0; y < OGimage.getHeight(); y++) {
            for(int x = 0; x < OGimage.getWidth(); x++) {
                ColorWrapper cw = new ColorWrapper(OGimage.getRGB(x, y));
                int avg = cw.getBlue() + cw.getGreen() + cw.getRed();
                avg /= 3;
                greyImage[x][y] = new RGBWrapper(avg, avg, avg, x, y);
            }
        }
        selected = ogImage;
        
        clusterImage = new RGBWrapper[OGimage.getHeight()][OGimage.getWidth()];
        ba = new BasicAgent(OGimage);
        centers = new RGBWrapper[NUM_CLUSTERS];
        ArrayList<ArrayList<RGBWrapper>> clusters = ba.cluster(CLUSTER_ITERATIONS, centers, NUM_CLUSTERS);
        for(int i = 0; i < NUM_CLUSTERS; i++) {
            for(RGBWrapper ptr : clusters.get(i)) {
                clusterImage[ptr.x][ptr.y] = new RGBWrapper(centers[i].red, centers[i].green, centers[i].blue, ptr.x, ptr.y);
            }
        }
        
        basicAgentRun = false;
        improvedAgentRun = false;
        
        zoom.setValue(zoom.getMax()/2);
        scale = zoom.getValue() / (zoom.getMax()/2);
    }
    

    @FXML
    void onGrey(ActionEvent event) throws IOException {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        selected = greyImage;
        drawSelected();   
    }
    
    @FXML
    void onDrag(MouseEvent event) throws IOException {
        if(OGimage == null)
            return;
        
        scale = zoom.getValue() / (zoom.getMax()/2);
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        for(int y = 0; y < OGimage.getHeight(); y++) {
            for(int x = 0; x < OGimage.getWidth(); x++) {
                gc.setStroke(Color.rgb(selected[x][y].red, selected[x][y].green, selected[x][y].blue));
                gc.strokeLine(x*scale, y*scale, x*scale, y*scale);
            }
        }
        
    }
    
    @FXML
    void onCluster(ActionEvent event) {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        selected = clusterImage;
        drawSelected();
    }
    
    @FXML
    void onBasicAgent(ActionEvent event) throws InterruptedException {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        if(!basicAgentRun) {
            basicAgent = ba.run(greyImage, clusterImage, ogImage, centers);
            double errorFull = 0, errorTested = 0;
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = greyImage.length/2; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == (greyImage.length/2) || x == (greyImage.length-1)) {
                    }else {
                        double error = Math.sqrt(Math.pow((basicAgent[x][y].red - clusterImage[x][y].red), 2) +
                                Math.pow((basicAgent[x][y].green - clusterImage[x][y].green), 2) +
                                Math.pow((basicAgent[x][y].blue - clusterImage[x][y].blue), 2));
                        errorFull += error;
                    }   
                }
                for(int x = 0; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == (greyImage.length-1)) {
                    }else {
                        double error = Math.sqrt(Math.pow((basicAgent[x][y].red - clusterImage[x][y].red), 2) +
                                Math.pow((basicAgent[x][y].green - clusterImage[x][y].green), 2) +
                                Math.pow((basicAgent[x][y].blue - clusterImage[x][y].blue), 2));
                        errorFull += error;
                    }   
                }
            }
            System.out.println(errorTested);
            System.out.println(errorFull);
            basicAgentRun = true;
        }
        selected = basicAgent;
        drawSelected();
        
    }
    

    @FXML
    void onImprovedAgent(ActionEvent event) throws FileNotFoundException {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        if(!improvedAgentRun) {
            // Run improved agent
            ImprovedAgentSoftClass ia = new ImprovedAgentSoftClass();
            //double[][] weights = getWeights();
            
            improvedAgent = ia.runImproved(greyImage, clusterImage, ogImage, centers, null);
            double errorFull = 0, errorTested = 0;
            for(int y = 0; y < greyImage[0].length; y++) {
                for(int x = greyImage.length/2; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == (greyImage.length/2) || x == (greyImage.length-1)) {
                    }else {
                        double error = Math.sqrt(Math.pow((improvedAgent[x][y].red - clusterImage[x][y].red), 2) +
                                Math.pow((improvedAgent[x][y].green - clusterImage[x][y].green), 2) +
                                Math.pow((improvedAgent[x][y].blue - clusterImage[x][y].blue), 2));
                        errorTested += error;
                    }   
                }
                for(int x = 0; x < greyImage.length; x++) {
                    if(y == 0 || y == (greyImage[0].length-1) || x == 0 || x == (greyImage.length-1)) {
                    }else {
                        double error = Math.sqrt(Math.pow((improvedAgent[x][y].red - clusterImage[x][y].red), 2) +
                                Math.pow((improvedAgent[x][y].green - clusterImage[x][y].green), 2) +
                                Math.pow((improvedAgent[x][y].blue - clusterImage[x][y].blue), 2));
                        errorFull += error;
                    }   
                }
            }
            System.out.println(errorTested);
            System.out.println(errorFull);
            improvedAgentRun = true;
        }
        selected = improvedAgent;
        drawSelected();
    }
    
    private double[][] getWeights() throws FileNotFoundException{
        double[][] weights = new double[5][10];
        File w = new File("C:\\Users\\Family's RGB PGC\\git\\Intro-to-AI-CS440\\Colorizing_Project_4\\src\\Weights");
        Scanner reader = new Scanner(w);
        System.out.println("HELLO");
        
        for(int i = 0; i < weights.length; i++) {
            for(int j = 0; j < weights[0].length; j++) {
                weights[i][j] = reader.nextDouble();
            }
        }
        reader.close();
        return weights;
    }
    

    @FXML
    void onExport(ActionEvent event) throws IOException {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open Target File for the Export");
        chooser.getExtensionFilters().addAll(new ExtensionFilter("SELECT JPG", "*.jpg"),
                new ExtensionFilter("All Files", "*.*"));
        Stage stage = new Stage();
        File targetFile = chooser.showSaveDialog(stage);
        
        ImageIO.write(exportImage(clusterImage), "jpg", getDir(targetFile, "clusterImage"));
        ImageIO.write(exportImage(greyImage), "jpg", getDir(targetFile, "greyImage"));
        if(basicAgentRun)
            ImageIO.write(exportImage(basicAgent), "jpg", getDir(targetFile, "basicAgent"));
        if(improvedAgentRun)
            ImageIO.write(exportImage(improvedAgent), "jpg", getDir(targetFile, "improvedAgent"));
        
        
    }
    
    private String getInfo() {
        return "";
    }
    
    private File getDir(File dir, String name) {
        String fileName = dir.getName().substring(0, dir.getName().indexOf('.')) + " - " + name + dir.getName().substring(dir.getName().indexOf('.'));
        return new File(dir.getParent() + "\\" + fileName);
    }
    
    private BufferedImage exportImage(RGBWrapper[][] image) {
        BufferedImage img = new BufferedImage(image[0].length, image.length, BufferedImage.TYPE_INT_RGB);
        for(int i = 0; i < image[0].length; i++) {
            for(int j = 0; j < image.length; j++) {
                
                img.setRGB(image[i][j].x, image[i][j].y, (image[i][j].red << 16 | image[i][j].green << 8 | image[i][j].blue));
                
            }
        }
        return img;
    }
    
    

}

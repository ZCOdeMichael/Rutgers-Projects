package application;

public class RGBWrapper {
    int red, green, blue;
    int x, y;
    public RGBWrapper(int red, int green, int blue, int x, int y) {
        this.red = red;
        this.green = green;
        this.blue = blue;
        this.x = x;
        this.y = y;
    }
}

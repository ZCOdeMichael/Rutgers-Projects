package application;

import java.awt.Color;

public class ColorWrapper {
    
    private int red, green, blue;
    
    public ColorWrapper(int RGB) {
        Color color = new Color(RGB, true);
        red = color.getRed();
        green = color.getGreen();
        blue = color.getBlue();
    }
    
    public int getRed() {
        return red;
    }
    public int getGreen() {
        return green;
    }
    public int getBlue() {
        return blue;
    }
}

#include "header.h"

/*
 * Authors: Guilherme Teixeira (get38), Michael (mbz27)
*/

/*
-------------
|   Sort    |
-------------
*/

int num_In; // Number of inputs
int sort_Flag; // The type of sort the user wants to run {1 = insertionSort | 0 = quickSort}
int isString; // The type of data being sorted either Strings or Integer


/* void freeAll(input** list)
 * Method used to free list of pointers
 * @param input** list
*/
void freeAll(input** list){
  int i = num_In-1;;
  while (i >= 0){
    free((*(list[i])).String_Data);
    free((list[i]));
    i--;
  }
}

/* int comparatorInt(void* d1, void* d2)
 * Comparator for Integers
 * @params two parameters of void* type. Both parameters must be of input* type
 * @return -1 if argument d1 is less than argument d2, 1 if greater than, or 0 if equal
*/
int comparatorInt(void* d1, void* d2){
  int i = (*(input*)d1).num_Data;
  int i2 = (*(input*)d2).num_Data;
  if((i) < (i2)) return -1;
  if((i) > (i2)) return 1;
  return 0;
} // Comparator for Integers

/* int comparatorStr(void* s1, void* s2)
 * Comparator for String
 * @params two parameters of void* type. Both parameters must be of input* type
 * @return -1 if argument s1 is lexicographically less than argument s2, 1 if greater than, or 0 if equal
*/
int comparatorStr(void* s1, void* s2){    
  
      input* temp1 = (input*)s1;
      input* temp2 = (input*)s2;
      char* tempA = (*temp1).String_Data;
      char* tempB = (*temp2).String_Data;

      if (*tempA == '\0' && *tempB == '\0') return 0;
      if(*tempA == '\0') return -1;
      if(*tempB == '\0') return 1;
      while (*tempA != '\0' && *tempB != '\0'){
        if((int)(*tempA) < (int)(*tempB)) return -1;
        else if ((int)(*tempA) > (int)(*tempB)) return 1;
        else{
          tempA++;
          tempB++;
        }
      }
      if(*tempA == '\0' && *tempB != '\0') return 1;
      if(*tempA != '\0' && *tempB == '\0') return -1;
      if(*tempA == '\0' && *tempB == '\0') return 0;
      return 0;
} // Comparator for Strings

/* int insertionSort(void* toSort, int (*comparator)(void*, void*))
 * Insertion Sort Algorithm
 * @param void* toSort - List to be sorted. Must be of type input**.
 * @param int (*comparator)(void*, void*) - Method for comparing the data contained in toSort.
 * returns 1 if successfully sorted, 0 otherwise.
*/
int insertionSort(void* toSort, int (*comparator)(void*, void*)){

    input** arr = (input**) toSort;      

    int i, j;
    input* key;

    for(i = 1; i < num_In; i++){
        key = ((input**)toSort)[i];
        j = i - 1;
        

        while(j >= 0 && (comparator((void*)((input**)toSort)[j], (void*)key) == 1)){
            ((input**)toSort)[j+1] = ((input**)toSort)[j];
            j = j - 1;
              
        }
        ((input**)toSort)[j+1] = key;  
    }
    return 1;
} // Completes a insertion sort on a void* [array]

/* int quickSort(void* toSort, int (*comparator)(void*, void*))
 * QuickSort Algorithm
 * @param void* toSort - List to be sorted. Must be of type input**.
 * @param int (*comparator)(void*, void*) - Method for comparing the data contained in toSort.
 * returns 1 if successfully sorted, 0 otherwise.
*/
int quickSort(void* toSort, int (*comparator)(void*, void*)){
    qSort((input**)toSort, 0, num_In-1, comparator);
    return 1;
} // Completes a quick sort on a void* [array]

int qSort(input** arr, int low, int high, int (*comparator)(void*, void*)){
    if(low < high){
        int spl = split(arr, low, high, comparator);
        qSort(arr, low, spl-1, comparator);
        qSort(arr, spl+1, high, comparator);
    }
} // The actual quickSort function because the original prototype didn't have enough parameters to work with

int split(input** arr, int l, int h, int (*comparator)(void*, void*)){
    input* pivot = arr[l];
    int i = l+1, j;
    for(j = (l+1); j <= h; j++){
        if(comparator((void*)arr[j], (void*)pivot) != 1){
            swap(arr[i], arr[j]);
            i++;
          
        }
    }
    swap(arr[i-1], arr[l]);
    return (i-1);
} // Splits the array using the first element as the pivot

int swap(input* p1, input* p2){
    input temp = *p1;
    *p1 = *p2;
    *p2 = temp;

} // Swaps two elements in an array


/*
-----------------------
|   Input Handling    |
-----------------------
*/

/* int checkAlgoInput(char* algorithm)
 * Function analyzes the input for the algorithm choice
 * Sets sort global variable for function choice (sort_Flag) and return the same value
 * {QuickSort = 1; InsertionSort = 0}
 * @param char* algorithm - String with the first user argument
*/
int checkAlgoInput(char* algorithm){
  if(strlen(algorithm) >2) return -1;
  char first = algorithm[0];
  if (first == '-'){
    char second = algorithm[1];
    if (second == 'q'){
	    sort_Flag = 0;
      return 0;
    }
    else if (second == 'i'){
	    sort_Flag = 1;
      return 1;
    }
  }
  return -1;   
}

/* int checkChar(char c)
 * Return 0 if char is ',', ' ', '\t' or '\n' (Ignore all separations),(commas are taken care of in listBuilder)
 * Return 1 else (if it is an ASCII character other than the separation char above)
 * @param char c - single char
*/
int checkChar(char c){
  if(c == ',' || c == ' ' || c == '\n' || c == '\t') return 0;
  return 1;
}

/* int checkType(char* buffer)
 * Function checks the type of content in the buffer built from reading the file
 * Sets global variable and returns how many tokens in the file
 * @param char* buffer - contents of the entire file
*/
int checkType(char* buffer){
  char* tempBuffer = buffer;
  int listSize = 0;
  isString = 0;
  while (*tempBuffer != '\0'){
    if(*tempBuffer == ',') listSize++;
    if(checkChar(*tempBuffer)){
      if((int)*tempBuffer>=97 && (int)*tempBuffer<=122){
	      isString = 1;
      }
    }
    tempBuffer++;
  }
  num_In = ++listSize;
  return listSize;
}

/* int listBuilder(char buffer[], int fileSize, input** list)
 * Builds the list based on isString global variable as String or Integer
 * @param char buffer[] - file containing all data collected from the file
 * @param int fileSize - how many bytes collected from the file
 * @param input** list - pointer to list being sorted
*/
int listBuilder(char buffer[], int fileSize, input** list){

  int counter = 0;
  char* tempBuffer = buffer;
  input** tempList = list;
  int i = 0;
  char tempS[fileSize];
  int malCounter = 0;
  memset(tempS,'\0',fileSize);
  //Iterates through the entire buffer
  while(counter<=fileSize){
    //If its a valid char (not a separation char) add it to tempS
    //i stores the size of String to be used in malloc if necessary
    if(checkChar(*tempBuffer) && counter<fileSize){
      tempS[i] = *tempBuffer;
      i++;
    }
    //If it is a comma, or the end of file finish the building the string and add it to list
    else if (*tempBuffer == ',' || counter == fileSize){
      //if reached the end of file and tempS is empty, then ignore the last empty token
      if(*tempS == '\0' && counter == fileSize){
        num_In--;
        break;
      }
      //Access element in list of inputs and allocate memory for it
      *tempList = (input*)malloc(sizeof(input));
      //Warning for unsuccessful malloc
      if(*tempList == NULL){
	      printf("Warning: malloc unsuccessful.");
      }
      malCounter = 0;
      //Tries to allocate memory up to 20 times
      while(*tempList == NULL && malCounter <20){
        *tempList = (input*)malloc(sizeof(input));
        malCounter++;
      }
      if(*tempList == NULL){
	      return -1;
      }
      //If global var isString is set to 1, then add element as a String
      if(isString == 1){
        (*(*tempList)).String_Data = (char*)malloc(sizeof(char)*(i+1));
        if((*(*tempList)).String_Data == NULL){
          printf("Warning: malloc unsuccessful.");
        }
        malCounter = 0;
        while((*(*tempList)).String_Data == NULL && malCounter <20){
          (*(*tempList)).String_Data = (char*)malloc(sizeof(char)*(i+1));
          malCounter++;
        }
        if((*(*tempList)).String_Data == NULL){
	        return -1;
        }
        strcpy((*(*tempList)).String_Data,tempS);
      }
      //Adds element as an integer
      else if (isString == 0){
        (*(*tempList)).num_Data = atoi(tempS);
      }
      //Resets tempS, i, and move the pointer to the next slot in tempList
      memset(tempS,'\0',fileSize);
      i = 0;
      tempList++;
    }
    tempBuffer++;
    counter++;
  }
  return 0;
}

/* void printList(input** list)
 * Prints the list based on the global variable isString.
 * @param input** list - list to be printed.
*/
void printList(input** list){
  input** tempList = list;
  int i =0;
  if(isString == 1){
    while(i<num_In){
      printf("%s\n",(*(*tempList)).String_Data);
      tempList++;;
      i++;
    }
  }
  else if(isString == 0){
     while(i < num_In){
       printf("%d\n",(*(*tempList)).num_Data);
      tempList++;
      i++;
    }
  }
  //printf("Total elements: %d\n",i);                                                                             
}

int main(int argc, char** argv){

  //If the inputs are less than the required (2)
  if (argc < 3){
    printf("Fatal error: expected two arguments, had one\n");
    return -1;
  }
  else{
    char* fName = argv[2]; // file name
    int algoChoice = checkAlgoInput(argv[1]); //Algorithm choice

    // If the algorithm choice is -1 then input is invalid
    // Else start application
    if(algoChoice>=0){
      //open file here - check for error
      int f;
      f = open(fName,O_RDONLY);
      if(f == -1 || errno != 0){
        printf("Fatal Error: \"%s\" does not exist\n",fName);
	      return -2;
      }
	    
      //Reads byte by byte in the file to find its size
      int fileSize = 1;
      char c[1];
      int n = read(f,c,1);
      n = read(f,c,1);
      //If first read is 0 and no errno is set, then file is empty
      if (n == 0 && errno == 0){
        printf("Warning: empty file.\n");
        return -3;
      }
      //Read the entire file to get its size
      while (n > 0){
        fileSize++;
        n = read(f,c,1);
        //error catcher
        if(errno != 0 || n < 0){
          n = 1;
          printf("Warning - Read unsuccesful: %s\n", strerror(errno));
          fileSize--;
        }
      }
      //printf("File size is: %d\n",fileSize);
	    close(f);
      //Starts data collection and stores all of it in buff var   
      f = open(fName, O_RDONLY);
      char buff[fileSize];
      memset(buff,'\0',fileSize);
      int i = 0;
      n = read(f,buff,fileSize);

      //If the amount of bytes read is less than the entire file, print warning and read the rest of the file byte by byte
      if (n<fileSize){
        printf("Warning - Read unsuccesful: %s\n", strerror(errno));
        int tempN = n;
        while(tempN<fileSize){
          n = read(f,buff+tempN,1);
          while(n==0)
            n = read(f, buff+tempN,1);
          tempN+=n;
        }
      }
      close(f);

      //printf("%s\n",buff);
      //check the type of data (String or int) that the program is holding and set global variables
      checkType(buff);

      //list building
      input** list = NULL;
      list = (input**)malloc(num_In*sizeof(input*));	
      //If malloc is unsuccessful - Next loop will atempt to allocate memory again up to 10 times
      if(list == NULL){
	      printf("Warning - malloc unsuccessful: %s\n", strerror(errno));
      }
      int malCounter = 0;
      while(list == NULL && malCounter <20){
	      list = (input**)malloc(num_In*sizeof(input*));
	      malCounter++;
      }
      //If after 20 attempts of allocations and the malloc still failed, then terminate the application
      if(list == NULL){
      	printf("Fatal Error: malloc unsuccessful over 20 times.\n");
	      return -4;
      }
      //printf("%d\n",isString);
      int listSuccess = listBuilder(buff,fileSize,list);
      if(listSuccess == -1){
      	printf("Fatal Error: malloc in listBuilder unsuccessful over 20 times.\n");
	      return -4;
      }
	    if(list == NULL){
        printf("Warning: empty file.\n");
        return -3;
      }
      //printf("The current list: \n");
      //printList(list);
      //printf("-- End of list --\n");
      if(isString == 1){
        if(sort_Flag == 1)
          insertionSort(list,comparatorStr);
        else
          quickSort(list,comparatorStr);
        
      }
      if(isString == 0){
        if(sort_Flag == 1)
          insertionSort(list,comparatorInt);
        else
          quickSort(list,comparatorInt);
      }
      //printf("\nThe New list: \n");
      printList(list);
      //printf("-- End of list --\n");
      freeAll(list);
      free(list);
      return 0;
    }
    else{
      printf("Fatal error: \"%s\" is not a valid command\n",argv[1]);
      return -3;
    }
  }
}
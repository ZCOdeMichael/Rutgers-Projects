Authors: Guilherme Teixeira get38, Michael Zhang mbz27

NAME
    fileSort.c - Sort and display the contents of a file

SYNOPSIS 
    #include "header.h"
        #include <errno.h>
        #include <stdio.h>
        #include <stdlib.h>
        #include <string.h>
        #include <unistd.h>
        #include <fcntl.h>
    
    int comparatorInt(void*, void*);
    int comparatorStr(void*, void*);

    int insertionSort(void*, int(*comparator)(void*, void*));
    int quickSort(void*, int(*comparator)(void*, void*));
        int qSort(input**, int, int, int(*comparator)(void*, void*));
        int split(input**, int, int, int(*comparator)(void*, void*));
        int swap(input*, input*);

    int checkAlgoInput(char*);
    int checkChar(char);
    int checkType(char*);
    int listBuilder(char[], int, input**);
    void printList(input**);

    void freeAll(input** list);
    
DESCRIPTION
    Program accepts 2 user inputs. 
    The first must be the COMMAND, or choice, of which sorting algorithm to use.
        - Acceptable commands are "-q" and "-i"
    The second input must be the FILE NAME.

    The flow of the main is as follows:
        - Checks command input and proceed if valid.
        - Iterate through file and count its total size in bytes.
        - Iterate through file and collect all of its data.
        - Use function checkType(char*) to determine if the file holds Strings or Integers, count tokens, and sets corresponding global variables.
            - isString = {Strings: 1; Integers: 0}
            - num_In: number of tokens in the file
        - Creates a list using listBuilder(char[], int, input**) function.
        - Uses chosen algorithm to sort the list.
        - Uses printList(input**) to display final results.
        - Free all allocated memory spaces.
RETURN
    Returns 0 in a sucessful run.
        Displays output to command line.
    Returns -1 if COMMAND input is invalid.
    Returns -2 if FILE NAME does not exist/invalid.
    Returns -3 if file is empty.
    Returns -4 if program fails to allocate memory over 20 times.

NOTES
    Below you will find method definitions and signatures of all methods used in this program:

    /* int comparatorInt(void* d1, void* d2)
    * Comparator for Integers
    * @params two parameters of void* type. Both parameters must be of input* type
    * @return -1 if argument d1 is less than argument d2, 1 if greater than, or 0 if equal
    */

    /* int comparatorStr(void* s1, void* s2)
    * Comparator for String
    * @params two parameters of void* type. Both parameters must be of input* type
    * @return -1 if argument s1 is lexicographically less than argument s2, 1 if greater than, or 0 if equal
    */

    /* int insertionSort(void* toSort, int (*comparator)(void*, void*))
    * Insertion Sort Algorithm
    * @param void* toSort - List to be sorted. Must be of type input**.
    * @param int (*comparator)(void*, void*) - Method for comparing the data contained in toSort.
    * returns 1 when finished sorting.
    */
    
    /* int quickSort(void* toSort, int (*comparator)(void*, void*))
    * QuickSort Algorithm
    * @param void* toSort - List to be sorted. Must be of type input**.
    * @param int (*comparator)(void*, void*) - Method for comparing the data contained in toSort.
    * returns 1 when finished sorting.
    */
    
    /* int checkAlgoInput(char* algorithm)
    * Function analyzes the input for the algorithm choice
    * Sets sort global variable for function choice (sort_Flag) and return the same value
    * {QuickSort = 1; InsertionSort = 0}
    * @param char* algorithm - String with the first user argument
    */

    /* int checkChar(char c)
    * Return 0 if char is ',', ' ', '\t' or '\n' (Ignore all separations),(commas are taken care of in listBuilder)
    * Return 1 else (if it is an ASCII character other than the separation char above)
    * @param char c - single char
    */

    /* int checkType(char* buffer)
    * Function checks the type of content in the buffer built from reading the file
    * Sets global variable and returns how many tokens in the file
    * @param char* buffer - contents of the entire file
    */

    /* int listBuilder(char buffer[], int fileSize, input** list)
    * Builds the list based on isString global variable as String or Integer
    * @param char buffer[] - file containing all data collected from the file
    * @param int fileSize - how many bytes collected from the file
    * @param input** list - pointer to list being sorted
    */

    /* void printList(input** list)
    * Prints the list based on the global variable isString.
    * @param input** list - list to be printed.
    */

    /* void freeAll(input** list)
    * Method used to free list of pointers
    * @param input** list
    */
#ifndef _HEADER_H
#define _HEADER_H

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

typedef struct _Input{
    int num_Data;
    char* String_Data;
    struct _input* next;
} input;


//Sorting Funcitons
int comparatorInt(void*, void*);
int comparatorStr(void*, void*);

int insertionSort(void*, int(*comparator)(void*, void*));
int quickSort(void*, int(*comparator)(void*, void*));
//Stuff for quick sort
int qSort(input**, int, int, int(*comparator)(void*, void*));
int split(input**, int, int, int(*comparator)(void*, void*));
int swap(input*, input*);

//Input Headling
int checkAlgoInput(char*);
int checkChar(char);
int checkType(char*);
int listBuilder(char[], int, input**);
void printList(input**);

//Free Function
void freeAll(input** list);

#endif
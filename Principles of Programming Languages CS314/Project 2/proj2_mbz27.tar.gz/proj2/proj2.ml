open Proj2_types;;

let reverse lt = List.fold_left (fun a x -> x::a) [] lt;;
let getFirst(a, b) = a;;
let getSecond(a, b) = b;;

(* -------buildParseTree------- *)

let rec sterm list = 
                match (List.hd(list)) with
                | "TRUE" -> (TreeNode ("S", [(TreeNode ("TRUE", []))]))
                | "FALSE" -> (TreeNode ("S", [(TreeNode ("FALSE", []))]))
                | "(" -> TreeNode ("S", [TreeNode ( "(", []); 
                                        TreeNode ( "T", (tterm (List.tl(list))) ); 
                                        TreeNode ( ")", [] )])
                | x -> TreeNode ("S", [TreeNode ( (List.hd(list)), [])])
        and tterm list =
                match (List.hd(list)) with
                | "not" -> [TreeNode ("not", []); sterm (List.tl(list))]
                | "and" -> (andT list)
                | "or" -> (orT list)
                | _ -> raise (Invalid_argument "Not in grammar")
        and andT list =
                match ((List.hd(List.tl(list)))) with
                | "(" -> [TreeNode ( "and", []); sterm(List.tl(list)); sterm((nextVar (List.tl(List.tl(list))) 1))] 
                | x -> [TreeNode ( "and", []); sterm(List.tl(list)); sterm(List.tl(List.tl(list)))] 
        and orT list =
                match ((List.hd(List.tl(list)))) with
                | "(" -> [TreeNode ( "or", []); sterm(List.tl(list)); sterm((nextVar (List.tl(List.tl(list))) 1))] 
                | x -> [TreeNode ( "or", []); sterm(List.tl(list)); sterm(List.tl(List.tl(list)))]
        and nextVar list n = if(n = 0)
                        then list
                        else
                        (match (List.hd(list)) with
                        | ")" -> nextVar (List.tl(list)) (n-1)
                        | "(" -> nextVar (List.tl(list)) (n+1)
                        | x -> nextVar (List.tl(list)) n);; 

let buildParseTree (input : string list) : tree = sterm input;;
  
(* -------buildParseTree------- *)

(* -------buildAbstractSyntaxTree------- *)

let getFt (TreeNode (x, _)) = x;;

let getSt (TreeNode (_, x)) = x;;

let rec traverse input = 
                match (getFt(input)) with
                | "S" -> nodeS (getSt(input))
                | "T" -> nodeT (getSt(input))
                | _ -> raise (Invalid_argument "Not in grammar")
        and traverseList input =
                match (getFt(List.hd(input))) with
                | "S" -> nodeS (getSt(List.hd(input)))
                | "T" -> nodeT (getSt(List.hd(input)))
                | _ -> raise (Invalid_argument "Not in grammar")
        and nodeS input =
                match (getFt(List.hd(input))) with
                | "TRUE" -> (TreeNode("TRUE", []))
                | "FALSE" -> (TreeNode("FALSE", []))
                | "(" -> (traverseList (List.tl(input)))
                | x -> (TreeNode(x, []))
        and nodeT input =
                match (getFt(List.hd(input))) with
                | "not" -> (TreeNode("not", [(traverseList (List.tl(input)))]))
                | "and" -> (TreeNode("and", (addList (List.tl(input))) ))
                | "or" ->  (TreeNode("or", (addList (List.tl(input))) ))
                | _ -> raise (Invalid_argument "Not in grammar")
        and addList input = [(traverseList input); (traverseList (List.tl(input)) )];;

let buildAbstractSyntaxTree (input : tree) : tree = traverse input;;

(* -------buildAbstractSyntaxTree------- *)

(* -------ScanVariable------- *)
let rec isDup elem lt = if lt = [] 
                            then false 
                            else (if List.hd(lt) = elem 
                                    then true 
                                    else (isDup elem (List.tl(lt))));;

let addVar lt curr = if (curr = "TRUE" || curr = "FALSE" || curr = "(" || curr = ")" ||  curr = "not" ||  curr = "and" ||  curr = "or") 
                        then lt 
                        else (if (isDup curr lt)
                                then lt
                                else (curr::lt));;


let scanVariable (input : string list) : string list = reverse(List.fold_left (addVar) [] input);;
(* -------ScanVariable------- *)

(* -------generateInitialAssignList------- *)
let genAssign lt var = (var,false)::lt;;

let generateInitialAssignList (varList : string list) : (string * bool) list = reverse(List.fold_left (genAssign) [] varList);;
(* -------generateInitialAssignList------- *)

(* -------generateNextAssignList------- *)

let nextAssign curr tp = if (getSecond(tp) = true)
                                then (if getSecond(curr) = true
                                        then ((getFirst(curr), false)::getFirst(tp), true)
                                        else ((getFirst(curr), true)::getFirst(tp), false))
                                else ((getFirst(curr), getSecond(curr))::getFirst(tp), false);;


let generateNextAssignList (assignList : (string * bool) list) : (string * bool) list * bool = List.fold_right (nextAssign) assignList ([], true);;
(* -------generateNextAssignList------- *)

(* -------lookupVar------- *)
let rec lookVar tp var = if tp = [] 
                        then false
                        else (if (getFirst(List.hd(tp))) = var
                                then (getSecond(List.hd(tp)))
                                else lookVar (List.tl(tp)) var);;

let lookupVar (assignList : (string * bool) list) (str : string) : bool = lookVar assignList str;;
(* -------lookupVar------- *)

(* -------evaluateTree------- *)

let rec eval ast bList = 
                match (getFt(ast)) with
                | "TRUE" -> true
                | "FALSE" -> false
                | "not" -> (not(eval (List.hd(getSt(ast))) bList))
                | "and" -> ((eval (List.hd(getSt(ast))) bList) && (eval (List.hd(List.tl(getSt(ast)))) bList))
                | "or" ->  ((eval (List.hd(getSt(ast))) bList) || (eval (List.hd(List.tl(getSt(ast)))) bList))
                | x -> (lookupVar bList (getFt(ast)));;


let evaluateTree (t : tree) (assignList : (string * bool) list) : bool = eval t assignList;;
(* -------evaluateTree------- *)

(* -------satisfiable------- *)

let rec makeAssignList carry = if (getSecond(carry))
                                        then []
                                        else [carry] @ (makeAssignList (generateNextAssignList (getFirst(carry))));;


let satisfiable (input : string list) : (string * bool) list list = List.fold_left 
                                                        (fun lt carry -> if ( evaluateTree (buildAbstractSyntaxTree (buildParseTree input) ) (getFirst(carry)) )
                                                                        then (getFirst(carry)) :: lt 
                                                                        else lt) [] (makeAssignList ((generateInitialAssignList (scanVariable input)), false)) ;;

(* -------satisfiable------- *)


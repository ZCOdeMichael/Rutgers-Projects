#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "InstrUtils.h"
#include "Utils.h"


void doubleSize();
void add(int);
int find(int);
int numItems = 0;
int size = 10;

void doubleSize_ID();
void add_ID(int);
int find_ID(int);
int numID = 0;
int size_ID = 10;

int last_Int = 0;

int* list;
int* list_ID;


int main()
{
	Instruction *head;

	head = ReadInstructionList(stdin);
	if (!head) {
		WARNING("No instructions\n");
		exit(EXIT_FAILURE);
	}
	list = (int*) malloc(sizeof(int)*size);
	list_ID = (int*) malloc(sizeof(int)*size_ID);
	for(int i = 0; i < size; i++){
		list[i] = -1;
		list_ID[i] = -1;
	}
	Instruction *ptr_End = head;
	for(; ptr_End->next != NULL; ptr_End = ptr_End->next){}
	//printf("%d - %d\n", ptr_End->field1, ptr_End->field2);
	for(; ptr_End != NULL; ptr_End = ptr_End->prev){
		//printf("%d - %d\n", ptr_End->field1, ptr_End->field2);
		if(last_Int == 1){
			ptr_End = ptr_End->next;
			last_Int = 0;
		}

		if(ptr_End->opcode == 9 || ptr_End->opcode == 8){
			if(find_ID(ptr_End->field1) == -1){
				// does not exist in id list
				add_ID(ptr_End->field1);
			}
		}else{
			
			if(ptr_End->opcode == 2){
				if(find_ID(ptr_End->field1) == -1){
					// does not exist in id list - non critical <id>
					// CHECK FOR NULLS ON EITHER SIDE!!!!!

					if(ptr_End->next != NULL && ptr_End->prev != NULL){
						// Middle instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->prev->next = ptr_End->next;
						ptr_End->next->prev = ptr_End->prev;
						ptr_End = ptr_End->next;
						free(temp);
					}else if(ptr_End->next != NULL && ptr_End->prev == NULL){
						// First instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->next->prev = ptr_End->prev;
						ptr_End = ptr_End->next;
						free(temp);
						break;
					}else if(ptr_End->next == NULL && ptr_End->prev != NULL){
						// Last instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->prev->next = ptr_End->next;
						ptr_End = ptr_End->prev;
						free(temp);
						last_Int = 1;
					}else{
						free(head);
						head = NULL;
					}
				}else{
					// does exist in id list - critical <register>
					add(ptr_End->field2);
				}
			}else{
				
				if(find(ptr_End->field1) == -1){
					// does not exist in list - non critical <register>
					// CHECK FOR NULLS ON EITHER SIDE!!!!!
					
					if(ptr_End->next != NULL && ptr_End->prev != NULL){
						// Middle instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->prev->next = ptr_End->next;
						ptr_End->next->prev = ptr_End->prev;
						ptr_End = ptr_End->next;
						free(temp);
					}else if(ptr_End->next != NULL && ptr_End->prev == NULL){
						// First instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->next->prev = ptr_End->prev;
						ptr_End = ptr_End->next;
						free(temp);
						break;
					}else if(ptr_End->next == NULL && ptr_End->prev != NULL){
						// Last instruction is dead code
						Instruction *temp = ptr_End;
						ptr_End->prev->next = ptr_End->next;
						ptr_End = ptr_End->prev;
						free(temp);
						last_Int = 1;
					}else{
						free(head);
						head = NULL;
					}
					
				}else{
					// does exist in list - critical <register>
					if(ptr_End->opcode == 0){
						// stores id if it is not in the list_ID
						if(find_ID(ptr_End->field2) == -1){
							add_ID(ptr_End->field2);
						}
					}else if(ptr_End->opcode == 1){
						// does nothing because of constants #
					}else{
						// ADD, SUB, MUL, AND, XOR
						if(find(ptr_End->field2) == -1){
							add(ptr_End->field2);
						}
						if(find(ptr_End->field3) == -1){
							add(ptr_End->field3);
						}
					}
				}
				
			}
			
		}
	}

	if(head->opcode == 9 || head->opcode == 8){
		// does nothing because guarantee critical
	}else if(head->opcode == 2){
		// STORE
		if(find_ID(head->field1) == -1){
			free(head);
			head = NULL;
		}
	}else{
		// Other inst. to compare registers
		if(find(head->field1) == -1){
			free(head);
			head = NULL;
		}
	}
	free(list);
	free(list_ID);
	/*
	for(Instruction *ptr = head; ptr != NULL; ptr = ptr->next){
		printf("%d - %d\n", ptr->field1, ptr->field2);
		ptr->critical = '1';
	}*/

	/* YOUR CODE GOES HERE */
	if (head) {
		PrintInstructionList(stdout, head);
		DestroyInstructionList(head);
	}
	return EXIT_SUCCESS;
}

void doubleSize(){
    int* list1 = (int*) malloc(sizeof(int)*size*2);
    for(int i = 0; i < size*2; i++){
        list1[i] = -1;
    }
    for(int i = 0; i < size; i++){
        list1[i] = list[i]; 
    }
    size = size*2;
    free(list);
    list = list1;
}

void add(int item){
    if(numItems == size){
        doubleSize();
    }
    list[numItems] = item;
    numItems++;
}

int find(int item){
    for(int i = 0; i < numItems; i++){
        if(list[i] == item){
            return i;
        }
    }
    return -1;
}

void doubleSize_ID(){
	int* list1 = (int*) malloc(sizeof(int)*size_ID*2);
    for(int i = 0; i < size_ID*2; i++){
        list1[i] = -1;
    }
    for(int i = 0; i < size_ID; i++){
        list1[i] = list_ID[i]; 
    }
    size_ID = size_ID*2;
    free(list);
    list_ID = list1;
}
void add_ID(int item){
	if(numID == size_ID){
        doubleSize_ID();
    }
    list_ID[numID] = item;
    numID++;
}
int find_ID(int item){
    for(int i = 0; i < numID; i++){
        if(list_ID[i] == item){
            return i;
        }
    }
    return -1;
}
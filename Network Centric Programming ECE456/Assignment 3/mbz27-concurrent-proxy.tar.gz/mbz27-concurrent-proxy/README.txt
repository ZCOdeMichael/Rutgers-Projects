To run the program run the Makefile then run the executable proxy with these arguments:
./proxy <port number> <fork/thread>

./proxy <port number> fork
This will run the proxy in a multi processing mode. The program will fork a process everytime a http request has been made.

./proxy <port number> thread
This will run the proxy in a multi threaded mode. The program will create a thread everytime a http request has been made.


Notice:
I have used the sample proxy program that was given for the assignment. I just simply turned it into a multi process/thread 
program therefore it is quite slow with responding to requests since it still has the extra features that was provided in the 
sample proxy program. 

I tested on the example.com site and it took quite a while for the program to respond and log the entries.
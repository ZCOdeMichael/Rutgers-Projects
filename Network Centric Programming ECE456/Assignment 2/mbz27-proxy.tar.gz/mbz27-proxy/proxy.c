/*
 * proxy.c - A Simple Sequential Web proxy
 *
 * Course Name: 14:332:456-Network Centric Programming
 * Assignment 2
 * Student Name:______________________
 * 
 * IMPORTANT: Give a high level description of your code here. You
 * must also provide a header comment at the beginning of each
 * function that describes what that function does.
 */ 

#include "csapp.h"

/*
 * Function prototypes
 */
void format_log_entry(char *logstring, struct sockaddr_in *sockaddr, char *uri, int size);

char* getURL(char* request, int size);
char* getPort(char* request, int size);
char* getDir(char* request, int size);
char* getWebRequest(char* request, int size);

#define REQUEST_BUFFER_SIZE 2048
#define BUFFERSIZE 100
#define DEFAULT_PORT 80

FILE* log_file;
int client_sock, new_socket, size_reponse;

typedef struct linkLists{
    char data[BUFFERSIZE];
    struct linkLists* next;
} linkList;

char getIndex(linkList* head, int index){
    int node_Index = index / BUFFERSIZE;
    int offset = index % BUFFERSIZE;
    linkList* ptr = head;
    int i = 0;
    for(; i < node_Index; i++){
        ptr = ptr->next;
    }
    return ptr->data[offset];
}

void handle_sigint(int sig) { 
    fclose(log_file);
    close(client_sock);
    close(new_socket);
    exit(1);
}

char* getResponse(int fd){
    linkList* head = NULL; 
    linkList* tail = NULL;
    char buffer[BUFFERSIZE+1];
    int size = 0, valread = 0;
    
    do{
        memset(buffer, '\0', BUFFERSIZE+1);
        valread = read(fd, buffer, BUFFERSIZE);
        
        if(head == NULL){
            linkList* temp = (linkList*)malloc(sizeof(linkList));
            memset(temp->data, '\0', BUFFERSIZE);
            memcpy(temp->data, buffer, BUFFERSIZE);
            temp->next = NULL;
            head = temp;
            tail = temp;
        }else{
            linkList* temp = (linkList*)malloc(sizeof(linkList));
            memset(temp->data, '\0', BUFFERSIZE);
            memcpy(temp->data, buffer, BUFFERSIZE+1);
            temp->next = NULL;
            tail->next = temp;
            tail = temp;
        }

        size += valread;
    }while(valread == 100);

    char* response = (char*)malloc(sizeof(char) * (size+1));
    size_reponse = size+1;
    
    memset(response, '\0', size+1);
    int i = 0;
    for(; i < size; i++){
        response[i] = getIndex(head, i);
    }
    
    while(head != NULL){
        linkList* temp = head->next;
        free(head);
        head = temp;
    }

    return response;
}

/* 
 * main - Main routine for the proxy program 
 */
int main(int argc, char **argv) {
    /* Check arguments */
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port number>\n", argv[0]);
        exit(0);
    }

    log_file = fopen("proxy.log", "a"); // Appends to proxy.log file

    int server_fd, valread;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0){
        perror("Failed to create a socket");
        exit(EXIT_FAILURE);
    }
    bzero(&address, addrlen);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl (INADDR_ANY);
    address.sin_port = htons(atoi(argv[1]));
    if(bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0){
        perror("Failed to bind");
        exit(EXIT_FAILURE);
    }
    if(listen(server_fd, REQUEST_BUFFER_SIZE) < 0){
        perror("Failed to Listen");
        exit(EXIT_FAILURE);
    }
    
    signal(SIGINT, handle_sigint); // Signal handler when ^C to close the file descriptor for the log file and sockets

    char request_buffer[REQUEST_BUFFER_SIZE];
    while(1){
        if((new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen)) < 0){
            perror("Failed to accept connection");
            exit(EXIT_FAILURE);
        }
        printf("Accepts Socket Connection\n"); // Accepted Server connection

        memset(request_buffer, '\0', REQUEST_BUFFER_SIZE); // Clears request buffer
        
        valread = read(new_socket, request_buffer, REQUEST_BUFFER_SIZE); // Reads in request to buffer
        printf("Browser Request: \n%s\nRequest Size: %d\n", request_buffer, valread);
        
        int port;
        char* porttest = getPort(request_buffer,valread); 
        char* url = getURL(request_buffer, valread);
        char* web_request = getWebRequest(request_buffer, valread);

        // Sets the port
        if(strlen(porttest) != 0){
            port = atoi(porttest);
        }else{
            port = DEFAULT_PORT;
        }
        
        // Connects to webserver
        client_sock = open_clientfd(url, port);

        if(client_sock < 0){
            printf("Could not establish connection to webserver\n");
            close(new_socket);
            exit(1);
        }else{
            printf("Successfully connected to the webserver\n");
        }
    
        // Sends the request to the webserver
        printf("Sent web request to webserver: \n%s\n", web_request);
        valread = write(client_sock, web_request, strlen(web_request));
        
        char* response = getResponse(client_sock);
        
        printf("Response from webserver: \n%s\n", response);
        valread = write(new_socket, response, size_reponse);

        char temp[REQUEST_BUFFER_SIZE];
        char log[REQUEST_BUFFER_SIZE*2];
        memset(temp, '\0', REQUEST_BUFFER_SIZE);
        memset(log, '\0', REQUEST_BUFFER_SIZE*2);
        
        format_log_entry(temp, &address, url, size_reponse);
        sprintf(log, "%s %d\n", temp, size_reponse);

        printf("Saved Log entry: \n%s\n", log);
        fputs(log, log_file);

        free(response);
        free(porttest);
        free(url);
        free(web_request);
        close(client_sock);
        close(new_socket);
        
    }

    exit(0);
}


char* getURL(char* request, int size){
    char* url = (char*)malloc(sizeof(char) * (size+1));
    memset(url, '\0', size+1);
    int i, start_slash = 0, start_colon = 0, counter = 0;
    for(i = 0; i < size; i++){
        if(request[i] == '/' || request[i] == ':'){
            if(request[i] == '/'){
                start_slash++;
            }
            if(request[i] == ':'){
                start_colon++;
            }
        }else{    
            if(start_slash == 2){
                url[counter] = request[i]; 
                counter++;
            }
        }
        if(start_slash == 3 || start_colon == 2 || request[i] == '\n'){
            break;
        }
    }
    return url;
}

char* getPort(char* request, int size){
    char* port = (char*)malloc(sizeof(char) * (size+1));
    memset(port, '\0', size+1);
    int i, start_slash = 0, start_colon = 0, counter = 0;
    for(i = 0; i < size; i++){
        if(request[i] == '/' || request[i] == ':'){
            if(request[i] == '/'){
                start_slash++;
            }
            if(request[i] == ':'){
                start_colon++;
            }
        }else{    
            if(start_colon == 2 && start_slash == 2){
                port[counter] = request[i]; 
                counter++;
            }
        }
        if(start_slash == 3 || request[i] == '\n'){
            break;
        }
        
    }
    return port;
}

char* getDir(char* request, int size){
    char* port = (char*)malloc(sizeof(char) * (size+1));
    memset(port, '\0', size+1);
    int i, start_slash = 0, counter = 0;
    for(i = 0; i < size; i++){
        //printf("%c\n", request[i]);
        if(request[i] == '\n'){
            break;
        } 
        if(request[i] == '/'){
            start_slash++;
        }
        if(start_slash >= 3){
            port[counter] = request[i];
            counter++;
        }
    
           
    }
    return port;
}

char* getInfo(char* request, int size){
    char* info = (char*)malloc(sizeof(char) * (size+1));
    memset(info, '\0', size+1);
    int i, count = 0, counter = 0;
    for(i = 0; i < size; i++){
        if(request[i] == '\0'){
            break;
        }
        if(request[i] == '\n'){
            count++;
        }
        if(count >= 1){
            info[counter] = request[i];
            counter++;
        }
    }
    return info;
}

char* getWebRequest(char* request, int size){
    char* web_Request = (char*)malloc(sizeof(char) * (size+1));
    memset(web_Request, '\0', size+1);
    char* dir = getDir(request, size);
    char* info = getInfo(request, size);
    sprintf(web_Request, "GET %s%s", dir, info);
    
    free(dir);
    return web_Request;
}

/*
 * format_log_entry - Create a formatted log entry in logstring. 
 * 
 * The inputs are the socket address of the requesting client
 * (sockaddr), the URI from the request (uri), and the size in bytes
 * of the response from the server (size).
 */
void format_log_entry(char *logstring, struct sockaddr_in *sockaddr, 
		      char *uri, int size)
{
    time_t now;
    char time_str[MAXLINE];
    unsigned long host;
    unsigned char a, b, c, d;

    /* Get a formatted time string */
    now = time(NULL);
    strftime(time_str, MAXLINE, "%a %d %b %Y %H:%M:%S %Z", localtime(&now));

    /* 
     * Convert the IP address in network byte order to dotted decimal
     * form. Note that we could have used inet_ntoa, but chose not to
     * because inet_ntoa is a Class 3 thread unsafe function that
     * returns a pointer to a static variable (Ch 13, CS:APP).
     */
    host = ntohl(sockaddr->sin_addr.s_addr);
    a = host >> 24;
    b = (host >> 16) & 0xff;
    c = (host >> 8) & 0xff;
    d = host & 0xff;


    /* Return the formatted log entry string */
    sprintf(logstring, "%s: %d.%d.%d.%d %s", time_str, a, b, c, d, uri);
}




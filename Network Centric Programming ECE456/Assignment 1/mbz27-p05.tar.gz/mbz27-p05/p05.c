#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <ctype.h>
#define BUFFERSIZE 10000


typedef struct linkLists{
    char data[BUFFERSIZE];
    struct linkLists* next;
} linkList;

void non_Syscall(int argc, char** argv, FILE* fp){
    int i = 2;
    for(; i < argc; i++){
        int len = strlen(argv[i]);
        int num_pattern = 0;
        int off_set = 0;
        while(1){
            int test = 1;
            int j = 0;
            for(; j < len; j++){
                int curr = fgetc(fp);
                if(feof(fp)){
                    test = -1;
                    break;
                }else{
                    if(tolower(((char) curr)) != tolower(argv[i][j])){
                        test = 0;
                    }
                }
            }
            if(test == -1){
                break;
            }else if(test == 1){
                num_pattern++;
            }else{
                off_set++;
                fseek(fp, off_set, SEEK_SET);
            }
        }


        printf("%d\n", num_pattern);

        fseek(fp, 0, SEEK_SET);
    }

    fclose(fp);
}

char getIndex(linkList* head, int index){
    int node_Index = index / BUFFERSIZE;
    int offset = index % BUFFERSIZE;
    linkList* ptr = head;
    int i = 0;
    for(; i < node_Index; i++){
        ptr = ptr->next;
    }
    return ptr->data[offset];
}

void syscalls(int argc, char** argv, int fd){
    char* buffer = (char*) calloc(BUFFERSIZE, sizeof(char));
    memset(buffer, '\0', BUFFERSIZE);
    int rd = read(fd, buffer, BUFFERSIZE);
    linkList* head = NULL;
    linkList* end = NULL;
    int file_Len = 0;
    while(rd > 0){
        linkList* temp = (linkList*) malloc(sizeof(linkList));
        if(head == NULL){
            memcpy(temp->data, buffer, BUFFERSIZE+1);
            temp->next = NULL;
            head = temp;
            end = temp;
            file_Len += strlen(buffer);
        }else{
            memcpy(temp->data, buffer, BUFFERSIZE+1);
            temp->next = NULL;
            end->next = temp;
            end = temp;
            file_Len += strlen(buffer);
        }
        memset(buffer, '\0', BUFFERSIZE);
        rd = read(fd, buffer, BUFFERSIZE);
    }
    
    int i = 3;
    for(; i < argc; i++){
        int len = strlen(argv[i]);
        int num_pattern = 0;
        int j = 0;
        
        int status = 1;
        for(; j < file_Len; j++){
            int k = 0;
            int inc = 1;
            for(; k < len; k++){
                if((k+j) == file_Len){
                    status = 0;
                    break;
                }else{
                    if(tolower(getIndex(head, k+j)) != tolower(argv[i][k])){
                        inc = 0;
                    }
                }
            }
            if(status == 0){
                break;
            }
            if(inc == 1){
                num_pattern++;
            }
        }
        printf("%d\n", num_pattern);
    }

    linkList* ptr = head;
    while(ptr != NULL){
        linkList* temp = ptr->next;
        free(ptr);
        ptr = temp;
    }
    free(buffer);
    close(fd);

}


int main(int argc, char** argv){
    
    if(argc < 2){
        return -1;
    }

    if(strcmp("--systemcalls", argv[1]) == 0){
        if(argc == 2){
            return -1;
        }

        int fd = open(argv[2], O_RDONLY, 0);
        if(fd < 0){
            perror("File error\n");
            return -1;
        }

        syscalls(argc, argv, fd);
        return 0;

    }else{
        FILE* fp = fopen(argv[1], "r");
        if(fp == NULL){
            perror("File error\n");
            return -1;
        }
        
        if(argc == 2){
            fclose(fp);
            return -1;
        }
        
        

        non_Syscall(argc, argv, fp);
        return 0;
    }
}